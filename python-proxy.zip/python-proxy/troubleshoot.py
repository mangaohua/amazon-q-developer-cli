#!/usr/bin/env python3
"""
Troubleshooting script for Amazon Q Developer Proxy
"""

import os
import sys
import asyncio
import httpx

# Add current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from auth import BuilderIdAuth

async def diagnose_auth():
    """Diagnose authentication issues"""
    print("🔍 Diagnosing Authentication")
    print("=" * 30)
    
    auth = BuilderIdAuth()
    
    # Check if logged in
    is_logged_in = await auth.is_logged_in()
    print(f"Logged in: {'✅ Yes' if is_logged_in else '❌ No'}")
    
    if not is_logged_in:
        print("\n💡 Solution:")
        print("   For real AWS access: python cli.py login")
        print("   For testing: AMAZON_Q_TEST_MODE=true python cli.py login")
        return False
    
    # Check token details
    token = await auth.get_token()
    if token:
        print(f"Token type: {'🧪 Mock' if 'mock_access_token' in token.access_token else '🔐 Real'}")
        print(f"Expires: {token.expires_at}")
        print(f"Expired: {'❌ Yes' if token.is_expired() else '✅ No'}")
        print(f"Scopes: {', '.join(token.scopes) if token.scopes else 'None'}")
        
        if token.is_expired():
            print("\n💡 Solution: Token expired, please login again")
            return False
    
    return True

async def test_api_access():
    """Test API access"""
    print("\n🌐 Testing API Access")
    print("=" * 20)
    
    auth = BuilderIdAuth()
    token = await auth.get_token()
    
    if not token:
        print("❌ No token available")
        return False
    
    # Test with real API if not mock
    if "mock_access_token" not in token.access_token:
        print("🔍 Testing real API access...")
        
        headers = {
            "Authorization": f"Bearer {token.access_token}",
            "Content-Type": "application/x-amz-json-1.1",
            "X-Amz-Target": "CodeWhispererService.GenerateAssistantResponse",
            "User-Agent": "amazon-q-python-proxy/1.0.0"
        }
        
        # Simple test payload
        payload = {
            "conversationState": {
                "currentMessage": {
                    "userInputMessage": {
                        "content": "Hello"
                    }
                },
                "chatTriggerType": "Manual"
            }
        }
        
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(
                    "https://codewhisperer.us-east-1.amazonaws.com/generateAssistantResponse",
                    headers=headers,
                    json=payload
                )
                
                print(f"API Response: {response.status_code}")
                
                if response.status_code == 200:
                    print("✅ API access working")
                    return True
                elif response.status_code == 403:
                    print("❌ Access denied (403)")
                    print("💡 Possible causes:")
                    print("   - AWS account doesn't have Amazon Q Developer access")
                    print("   - Token doesn't have required permissions")
                    print("   - Service not available in your region")
                    return False
                elif response.status_code == 401:
                    print("❌ Authentication failed (401)")
                    print("💡 Solution: Please login again")
                    return False
                else:
                    print(f"❌ Unexpected response: {response.status_code}")
                    print(f"   Response: {response.text}")
                    return False
                    
        except Exception as e:
            print(f"❌ API test failed: {e}")
            return False
    else:
        print("🧪 Using mock token - API access will be simulated")
        return True

def check_server_status():
    """Check if server is running"""
    print("\n🖥️  Checking Server Status")
    print("=" * 25)
    
    import subprocess
    try:
        result = subprocess.run(
            ["curl", "-s", "http://127.0.0.1:8000/health"],
            capture_output=True,
            text=True,
            timeout=5
        )
        
        if result.returncode == 0:
            print("✅ Server is running")
            try:
                import json
                health_data = json.loads(result.stdout)
                print(f"   Status: {health_data.get('status', 'unknown')}")
                print(f"   Authenticated: {health_data.get('authenticated', 'unknown')}")
            except:
                print(f"   Response: {result.stdout}")
            return True
        else:
            print("❌ Server not responding")
            return False
            
    except subprocess.TimeoutExpired:
        print("❌ Server timeout")
        return False
    except FileNotFoundError:
        print("❌ curl not found, cannot test server")
        return False
    except Exception as e:
        print(f"❌ Server check failed: {e}")
        return False

async def main():
    """Main troubleshooting function"""
    print("🔧 Amazon Q Developer Proxy Troubleshooter")
    print("=" * 50)
    
    # Step 1: Check authentication
    auth_ok = await diagnose_auth()
    
    # Step 2: Test API access (if auth is ok)
    api_ok = False
    if auth_ok:
        api_ok = await test_api_access()
    
    # Step 3: Check server status
    server_ok = check_server_status()
    
    # Summary and recommendations
    print("\n📋 Summary")
    print("=" * 10)
    print(f"Authentication: {'✅' if auth_ok else '❌'}")
    print(f"API Access: {'✅' if api_ok else '❌'}")
    print(f"Server Status: {'✅' if server_ok else '❌'}")
    
    print("\n💡 Recommendations:")
    
    if not auth_ok:
        print("1. Fix authentication first:")
        print("   python cli.py login")
    elif not api_ok:
        print("1. Check AWS account permissions")
        print("2. Try test mode: AMAZON_Q_TEST_MODE=true python cli.py login")
        print("3. Contact AWS support if you should have access")
    elif not server_ok:
        print("1. Start the server:")
        print("   python start_server.py")
    else:
        print("✅ Everything looks good!")
        print("   You can use the proxy normally")
    
    print("\n🔗 Quick Commands:")
    print("   python cli.py status          # Check auth status")
    print("   python cli.py logout          # Clear auth")
    print("   python cli.py login           # Login (real)")
    print("   AMAZON_Q_TEST_MODE=true python cli.py login  # Login (test)")
    print("   python start_server.py        # Start server")
    print("   python troubleshoot.py        # Run this again")

if __name__ == "__main__":
    asyncio.run(main())
