#!/usr/bin/env python3
"""
Setup verification script
"""

import sys
import subprocess
import importlib
import platform
import os

def check_python_version():
    """Check Python version"""
    print("🐍 Checking Python version...")
    version = sys.version_info
    print(f"   Python {version.major}.{version.minor}.{version.micro}")
    
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print("   ❌ Python 3.8+ is required")
        return False
    else:
        print("   ✅ Python version is compatible")
        return True

def check_dependencies():
    """Check required dependencies"""
    print("\n📦 Checking dependencies...")
    
    required_packages = [
        'fastapi',
        'uvicorn', 
        'pydantic',
        'httpx',
        'boto3',
        'cryptography',
        'jose',
        'aiofiles'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            importlib.import_module(package)
            print(f"   ✅ {package}")
        except ImportError:
            print(f"   ❌ {package} (missing)")
            missing_packages.append(package)
    
    if missing_packages:
        print(f"\n   Missing packages: {', '.join(missing_packages)}")
        print("   Run: pip install -r requirements.txt")
        return False
    else:
        print("   ✅ All dependencies are installed")
        return True

def check_secure_storage():
    """Check secure storage functionality"""
    print("\n🔐 Checking secure storage functionality...")
    
    try:
        # Add current directory to Python path
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        
        from auth.simple_storage import SimpleSecureStorage
        
        # Test secure storage
        test_storage = SimpleSecureStorage()
        test_key = "test-key"
        test_value = "test-value-123"
        
        # Try to set and get a test value
        test_storage.store_secret(test_key, test_value)
        retrieved_value = test_storage.get_secret(test_key)
        
        if retrieved_value == test_value:
            print("   ✅ Secure storage is working correctly")
            # Clean up test data
            test_storage.delete_secret(test_key)
            return True
        else:
            print("   ❌ Secure storage test failed")
            return False
            
    except Exception as e:
        print(f"   ❌ Secure storage error: {e}")
        return False

def check_network():
    """Check network connectivity"""
    print("\n🌐 Checking network connectivity...")
    
    import httpx
    
    endpoints_to_check = [
        "https://oidc.us-east-1.amazonaws.com",
        "https://codewhisperer.us-east-1.amazonaws.com"
    ]
    
    all_good = True
    
    for endpoint in endpoints_to_check:
        try:
            with httpx.Client(timeout=10.0) as client:
                response = client.get(endpoint)
                if response.status_code < 500:  # Any response is good
                    print(f"   ✅ {endpoint}")
                else:
                    print(f"   ⚠️  {endpoint} (status: {response.status_code})")
        except Exception as e:
            print(f"   ❌ {endpoint} (error: {e})")
            all_good = False
    
    if all_good:
        print("   ✅ Network connectivity is good")
    else:
        print("   ⚠️  Some endpoints are not reachable")
        print("   💡 Check your firewall and proxy settings")
    
    return all_good

def check_file_permissions():
    """Check file permissions"""
    print("\n📁 Checking file permissions...")
    
    import os
    from pathlib import Path
    
    # Check if we can create the auth directory
    home_dir = Path.home()
    auth_dir = home_dir / ".amazon-q"
    
    try:
        auth_dir.mkdir(parents=True, exist_ok=True)
        
        # Test file creation
        test_file = auth_dir / "test.txt"
        test_file.write_text("test")
        test_file.unlink()
        
        print(f"   ✅ Can write to {auth_dir}")
        return True
        
    except Exception as e:
        print(f"   ❌ Cannot write to {auth_dir}: {e}")
        return False

def main():
    """Main check function"""
    print("🔍 Amazon Q Developer Proxy - Setup Check")
    print("=" * 50)
    
    checks = [
        ("Python Version", check_python_version),
        ("Dependencies", check_dependencies),
        ("Secure Storage", check_secure_storage),
        ("Network", check_network),
        ("File Permissions", check_file_permissions)
    ]
    
    results = []
    
    for name, check_func in checks:
        try:
            result = check_func()
            results.append((name, result))
        except Exception as e:
            print(f"   ❌ {name} check failed: {e}")
            results.append((name, False))
    
    # Summary
    print("\n📋 Summary")
    print("-" * 20)
    
    all_passed = True
    for name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"   {name}: {status}")
        if not result:
            all_passed = False
    
    print("\n" + "=" * 50)
    
    if all_passed:
        print("🎉 All checks passed! You're ready to use the proxy.")
        print("\nNext steps:")
        print("1. Run: python cli.py login")
        print("2. Run: python cli.py server")
    else:
        print("⚠️  Some checks failed. Please fix the issues above.")
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
