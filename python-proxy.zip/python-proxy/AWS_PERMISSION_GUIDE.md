# 🔐 Amazon Q Developer 权限问题解决指南

## 问题现象

当你使用真实的 AWS 认证登录后，调用 API 时收到：
```json
{"detail":"Access denied. Please ensure your AWS account has Amazon Q Developer access."}
```

这表明你的 AWS 账户没有 Amazon Q Developer 的访问权限。

## 🎯 解决方案

### 1. 检查 Amazon Q Developer 服务状态

#### 1.1 登录 AWS 控制台
- 访问 [AWS 控制台](https://console.aws.amazon.com/)
- 使用你的 AWS 账户登录

#### 1.2 搜索 Amazon Q Developer
- 在控制台搜索框中输入 "Amazon Q" 或 "CodeWhisperer"
- 查看是否能找到相关服务

#### 1.3 检查服务可用性
- Amazon Q Developer 可能在某些地区不可用
- 确认你的账户地区是否支持此服务
- 推荐使用 `us-east-1` (北弗吉尼亚) 地区

### 2. 个人 AWS 账户

#### 2.1 免费层用户
如果你使用的是 AWS 免费层账户：
- Amazon Q Developer 可能需要付费订阅
- 检查 [Amazon Q Developer 定价页面](https://aws.amazon.com/q/developer/pricing/)
- 考虑升级到付费计划

#### 2.2 激活服务
1. 在 AWS 控制台中找到 Amazon Q Developer
2. 点击 "开始使用" 或 "激活服务"
3. 按照提示完成服务激活
4. 可能需要提供付费信息

### 3. 企业/组织账户

#### 3.1 联系管理员
如果你使用的是企业 AWS 账户：
- 联系你的 AWS 管理员
- 请求 Amazon Q Developer 访问权限
- 提供你的 IAM 用户名或角色信息

#### 3.2 检查 IAM 权限
管理员需要为你的 IAM 用户/角色添加以下权限：
```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "codewhisperer:GenerateRecommendations",
                "codewhisperer:GenerateCompletions",
                "codewhisperer:GenerateAssistantResponse"
            ],
            "Resource": "*"
        }
    ]
}
```

### 4. 地区和服务限制

#### 4.1 支持的地区
Amazon Q Developer 目前主要在以下地区可用：
- `us-east-1` (北弗吉尼亚)
- `us-west-2` (俄勒冈)
- `eu-west-1` (爱尔兰)

#### 4.2 切换地区
如果你在不支持的地区：
```bash
# 重新登录并指定地区
python cli.py logout
python cli.py login --region us-east-1
```

### 5. 账户类型限制

#### 5.1 教育账户
- AWS Educate 账户可能有服务限制
- 联系 AWS 教育支持

#### 5.2 试用账户
- 某些试用账户可能无法访问所有服务
- 考虑升级到完整账户

## 🔍 诊断步骤

### 步骤 1: 验证认证
```bash
python cli.py status
```
确认使用的是真实令牌（不是 mock token）

### 步骤 2: 测试权限
```bash
python diagnose_real_auth.py
```
这会测试不同的 API 端点并提供详细的权限诊断

### 步骤 3: 检查 AWS 控制台
1. 登录 AWS 控制台
2. 搜索 "Amazon Q" 或 "CodeWhisperer"
3. 查看服务状态和可用性

### 步骤 4: 联系支持
如果以上步骤都无法解决问题：
- 创建 AWS 支持工单
- 说明你无法访问 Amazon Q Developer API
- 提供你的账户 ID 和地区信息

## 🧪 临时解决方案

如果你需要立即测试代理功能，可以使用测试模式：

```bash
# 使用测试模式
python cli.py logout
AMAZON_Q_TEST_MODE=true python cli.py login
python start_server.py
```

测试模式特点：
- ✅ 不需要 AWS 权限
- ✅ 返回模拟的 AI 响应
- ✅ 完全兼容 OpenAI API
- ✅ 适合开发和集成测试

## 📞 获取帮助

### AWS 官方支持
- [AWS 支持中心](https://console.aws.amazon.com/support/)
- [Amazon Q Developer 文档](https://docs.aws.amazon.com/amazonq/)
- [CodeWhisperer 文档](https://docs.aws.amazon.com/codewhisperer/)

### 社区支持
- [AWS 开发者论坛](https://forums.aws.amazon.com/)
- [Stack Overflow](https://stackoverflow.com/questions/tagged/amazon-q)
- [AWS Reddit 社区](https://www.reddit.com/r/aws/)

## 🎯 总结

Amazon Q Developer 的 403 权限错误通常是由以下原因造成的：

1. **服务未激活** - 需要在 AWS 控制台中激活服务
2. **地区不支持** - 需要切换到支持的地区
3. **账户类型限制** - 某些账户类型可能无法访问
4. **IAM 权限不足** - 需要管理员添加相应权限
5. **付费要求** - 可能需要付费订阅

建议按照上述步骤逐一排查，如果问题仍然存在，请联系 AWS 支持获取帮助。

同时，你可以使用测试模式来验证代理的功能和集成，这不需要任何 AWS 权限。
