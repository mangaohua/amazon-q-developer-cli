# Amazon Q Developer Python Proxy

这是一个用 Python 实现的 Amazon Q Developer 代理服务，提供与 OpenAI API 兼容的 HTTP 接口。

## 功能特性

- 🔐 完整的 Amazon Q Developer 认证流程（OAuth 2.0 Device Code Flow）
- 🌐 OpenAI 兼容的 HTTP API 接口
- 🔄 支持流式和非流式响应
- 💾 安全的令牌存储（使用系统密钥链）
- 🔄 自动令牌刷新
- 📊 完整的错误处理和日志记录

## 安装

1. 安装依赖：
```bash
pip install -r requirements.txt
```

2. 确保系统支持密钥链存储：
   - **Linux**: 安装 `python3-keyring` 和 `gnome-keyring` 或 `kwallet`
   - **macOS**: 内置支持
   - **Windows**: 内置支持

## 使用方法

### 1. 认证

首先需要登录到 Amazon Q Developer：

```bash
python cli.py login
```

这将：
1. 打开浏览器到 AWS 认证页面
2. 显示设备代码供你输入
3. 完成认证后保存令牌到系统密钥链

### 2. 检查认证状态

```bash
python cli.py status
```

### 3. 启动代理服务器

```bash
python cli.py server
```

默认在 `http://127.0.0.1:8000` 启动服务。

自定义端口和主机：
```bash
python cli.py server --host 0.0.0.0 --port 8080
```

### 4. 测试 API 连接

```bash
python cli.py test
```

## API 接口

### OpenAI 兼容接口

#### 1. 聊天完成 (Chat Completions)

```bash
curl -X POST http://127.0.0.1:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "amazon-q-developer",
    "messages": [
      {"role": "user", "content": "Hello, can you help me with Python?"}
    ]
  }'
```

#### 2. 流式响应

```bash
curl -X POST http://127.0.0.1:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "amazon-q-developer",
    "messages": [
      {"role": "user", "content": "Write a Python function to calculate fibonacci"}
    ],
    "stream": true
  }'
```

#### 3. 列出模型

```bash
curl http://127.0.0.1:8000/v1/models
```

### 认证接口

#### 1. 登录

```bash
curl -X POST http://127.0.0.1:8000/auth/login
```

#### 2. 登出

```bash
curl -X POST http://127.0.0.1:8000/auth/logout
```

#### 3. 检查认证状态

```bash
curl http://127.0.0.1:8000/auth/status
```

### 健康检查

```bash
curl http://127.0.0.1:8000/health
```

## 与现有工具集成

### 1. 使用 OpenAI Python 库

```python
import openai

# 配置客户端指向代理服务器
client = openai.OpenAI(
    base_url="http://127.0.0.1:8000/v1",
    api_key="dummy"  # 不需要真实的 API key
)

# 发送聊天请求
response = client.chat.completions.create(
    model="amazon-q-developer",
    messages=[
        {"role": "user", "content": "Hello, world!"}
    ]
)

print(response.choices[0].message.content)
```

### 2. 使用 curl

```bash
# 非流式请求
curl -X POST http://127.0.0.1:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "amazon-q-developer",
    "messages": [
      {"role": "system", "content": "You are a helpful assistant."},
      {"role": "user", "content": "Explain quantum computing"}
    ]
  }'

# 流式请求
curl -X POST http://127.0.0.1:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "amazon-q-developer",
    "messages": [
      {"role": "user", "content": "Write a Python web scraper"}
    ],
    "stream": true
  }'
```

### 3. 在其他应用中使用

任何支持 OpenAI API 的应用都可以通过修改 base URL 来使用这个代理：

- **Continue.dev**: 在设置中将 API base URL 设置为 `http://127.0.0.1:8000/v1`
- **Cursor**: 配置自定义 API 端点
- **其他 AI 编程工具**: 类似配置

## 项目结构

```
python-proxy/
├── auth/                   # 认证模块
│   ├── __init__.py
│   ├── builder_id.py      # Builder ID 认证实现
│   ├── database.py        # 安全存储
│   └── oauth.py           # OAuth 2.0 流程
├── api/                    # API 客户端模块
│   ├── __init__.py
│   ├── client.py          # Q Developer API 客户端
│   └── models.py          # 数据模型
├── server.py              # FastAPI 服务器
├── cli.py                 # 命令行接口
├── requirements.txt       # Python 依赖
└── README.md             # 说明文档
```

## 认证流程详解

1. **客户端注册**: 向 AWS SSO OIDC 注册 OAuth 客户端
2. **设备授权**: 启动设备代码流程，获取用户代码
3. **用户认证**: 用户在浏览器中输入代码完成认证
4. **令牌获取**: 轮询获取访问令牌和刷新令牌
5. **令牌存储**: 安全存储到系统密钥链
6. **自动刷新**: 令牌过期时自动使用刷新令牌更新

## 安全特性

- 🔐 使用系统密钥链安全存储敏感信息
- 🔄 自动令牌刷新，无需手动重新认证
- 🛡️ 请求头中正确设置 Bearer Token
- 📝 完整的错误处理和日志记录
- 🚫 不在代码中硬编码任何敏感信息

## 故障排除

### 1. 认证失败

```bash
# 检查认证状态
python cli.py status

# 重新登录
python cli.py logout
python cli.py login
```

### 2. 密钥链问题

在 Linux 上，确保安装了密钥链服务：

```bash
# Ubuntu/Debian
sudo apt install gnome-keyring

# 或者使用 KWallet
sudo apt install kwalletmanager
```

### 3. 网络问题

检查防火墙设置，确保可以访问：
- `https://oidc.us-east-1.amazonaws.com`
- `https://codewhisperer.us-east-1.amazonaws.com`

### 4. 调试模式

启用详细日志：

```bash
python cli.py --log-level debug status
python cli.py --log-level debug server
```

## 开发

### 运行测试

```bash
# 安装开发依赖
pip install pytest pytest-asyncio

# 运行测试
pytest
```

### 代码格式化

```bash
pip install black isort
black .
isort .
```

## 许可证

本项目采用与原始 Amazon Q Developer CLI 相同的双许可证：MIT 和 Apache 2.0。
