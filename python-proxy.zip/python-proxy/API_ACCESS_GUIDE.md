# 🔐 API 访问权限指南

## 问题说明

当你看到以下错误时：
```
HTTP/1.1 403 Forbidden
{"message":"User is not authorized to make this call.","reason":null}
```

这表示虽然认证成功了，但是你的 AWS 账户没有访问 Amazon Q Developer API 的权限。

## 🎯 解决方案

### 方案 1: 使用测试模式（推荐用于开发测试）

如果你只是想测试代理功能，可以使用测试模式：

```bash
# 1. 清除现有认证
python cli.py logout

# 2. 使用测试模式登录
AMAZON_Q_TEST_MODE=true python cli.py login

# 3. 启动服务器（会自动检测测试模式）
python start_server.py
```

测试模式特点：
- ✅ 不需要真实的 AWS 权限
- ✅ 返回模拟的响应内容
- ✅ 完全兼容 OpenAI API 格式
- ✅ 适合开发和集成测试

### 方案 2: 获取真实的 AWS 权限

如果你需要访问真实的 Amazon Q Developer API：

#### 2.1 检查账户权限

1. **登录 AWS 控制台**
2. **访问 Amazon Q Developer 页面**
3. **确认你的账户有访问权限**

#### 2.2 联系管理员

如果你是企业用户：
- 联系你的 AWS 管理员
- 请求 Amazon Q Developer 访问权限
- 确认你的 IAM 角色有必要的权限

#### 2.3 检查服务可用性

Amazon Q Developer 可能在某些地区不可用，请确认：
- 你的 AWS 账户地区
- Amazon Q Developer 服务可用性

## 🔍 诊断工具

使用内置的故障排除工具：

```bash
python troubleshoot.py
```

这会检查：
- ✅ 认证状态
- ✅ 令牌类型（真实 vs 模拟）
- ✅ API 访问权限
- ✅ 服务器状态

## 🚀 推荐的使用流程

### 开发和测试阶段

```bash
# 1. 使用测试模式
AMAZON_Q_TEST_MODE=true python cli.py login

# 2. 启动服务器
python start_server.py

# 3. 测试 API
curl -X POST http://127.0.0.1:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model": "amazon-q-developer", "messages": [{"role": "user", "content": "Hello!"}]}'
```

### 生产环境

```bash
# 1. 确保有真实的 AWS 权限
python cli.py login

# 2. 启动服务器
python start_server.py

# 3. 使用真实的 API
```

## 📊 模式对比

| 特性 | 测试模式 | 真实模式 |
|------|---------|---------|
| AWS 权限要求 | ❌ 不需要 | ✅ 需要 |
| API 响应 | 🧪 模拟内容 | 🔐 真实 AI 响应 |
| 开发测试 | ✅ 完美 | ✅ 可用 |
| 生产使用 | ❌ 不适合 | ✅ 推荐 |
| 成本 | 💰 免费 | 💰 按使用计费 |

## 🛠️ 常见问题

### Q: 为什么我有 AWS 账户但还是 403？
A: Amazon Q Developer 是一个独立的服务，需要特定的权限。不是所有 AWS 账户都自动有访问权限。

### Q: 测试模式的响应质量如何？
A: 测试模式返回预设的示例响应，主要用于测试 API 格式和集成，不是真实的 AI 生成内容。

### Q: 如何切换模式？
A: 
```bash
# 切换到测试模式
python cli.py logout
AMAZON_Q_TEST_MODE=true python cli.py login

# 切换到真实模式
python cli.py logout
python cli.py login
```

### Q: 服务器如何知道使用哪种模式？
A: 智能启动脚本 `start_server.py` 会自动检测你的认证类型并设置相应的模式。

## 🎯 总结

- **开发测试**: 使用测试模式，简单快速
- **生产环境**: 确保有真实的 AWS 权限
- **遇到 403**: 首先尝试测试模式
- **需要帮助**: 运行 `python troubleshoot.py`

无论使用哪种模式，代理都提供完全兼容的 OpenAI API 接口！
