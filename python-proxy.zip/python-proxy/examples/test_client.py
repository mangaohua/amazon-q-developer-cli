#!/usr/bin/env python3
"""
Example client for testing the Amazon Q Developer Proxy
"""

import asyncio
import json
import httpx
from openai import OpenAI

async def test_direct_api():
    """Test direct API calls using httpx"""
    print("🧪 Testing direct API calls...")
    
    base_url = "http://127.0.0.1:8000"
    
    async with httpx.AsyncClient() as client:
        # Test health check
        print("1. Health check...")
        response = await client.get(f"{base_url}/health")
        print(f"   Status: {response.status_code}")
        print(f"   Response: {response.json()}")
        
        # Test auth status
        print("\n2. Auth status...")
        response = await client.get(f"{base_url}/auth/status")
        print(f"   Status: {response.status_code}")
        print(f"   Response: {response.json()}")
        
        # Test models list
        print("\n3. List models...")
        response = await client.get(f"{base_url}/v1/models")
        print(f"   Status: {response.status_code}")
        print(f"   Models: {len(response.json()['data'])}")
        
        # Test chat completion
        print("\n4. Chat completion...")
        chat_request = {
            "model": "amazon-q-developer",
            "messages": [
                {"role": "user", "content": "Hello! Can you help me write a Python function?"}
            ]
        }
        
        response = await client.post(
            f"{base_url}/v1/chat/completions",
            json=chat_request,
            timeout=30.0
        )
        
        print(f"   Status: {response.status_code}")
        if response.status_code == 200:
            result = response.json()
            print(f"   Response: {result['choices'][0]['message']['content'][:100]}...")
        else:
            print(f"   Error: {response.text}")

def test_openai_client():
    """Test using OpenAI Python client"""
    print("\n🤖 Testing with OpenAI Python client...")
    
    # Configure client to use our proxy
    client = OpenAI(
        base_url="http://127.0.0.1:8000/v1",
        api_key="dummy"  # Not used, but required by the client
    )
    
    try:
        # Test non-streaming
        print("1. Non-streaming chat...")
        response = client.chat.completions.create(
            model="amazon-q-developer",
            messages=[
                {"role": "system", "content": "You are a helpful programming assistant."},
                {"role": "user", "content": "Write a Python function to calculate the factorial of a number."}
            ]
        )
        
        print(f"   Response: {response.choices[0].message.content[:200]}...")
        
        # Test streaming
        print("\n2. Streaming chat...")
        stream = client.chat.completions.create(
            model="amazon-q-developer",
            messages=[
                {"role": "user", "content": "Explain what is machine learning in simple terms."}
            ],
            stream=True
        )
        
        print("   Streaming response:")
        for chunk in stream:
            if chunk.choices[0].delta.content is not None:
                print(chunk.choices[0].delta.content, end="", flush=True)
        print("\n")
        
    except Exception as e:
        print(f"   Error: {e}")

async def test_streaming_api():
    """Test streaming API directly"""
    print("\n🌊 Testing streaming API...")
    
    base_url = "http://127.0.0.1:8000"
    
    chat_request = {
        "model": "amazon-q-developer",
        "messages": [
            {"role": "user", "content": "Write a Python web scraper example using requests and BeautifulSoup."}
        ],
        "stream": True
    }
    
    async with httpx.AsyncClient(timeout=60.0) as client:
        async with client.stream(
            "POST",
            f"{base_url}/v1/chat/completions",
            json=chat_request
        ) as response:
            print(f"   Status: {response.status_code}")
            
            if response.status_code == 200:
                print("   Streaming response:")
                async for line in response.aiter_lines():
                    if line.startswith("data: "):
                        data = line[6:]  # Remove "data: " prefix
                        if data == "[DONE]":
                            break
                        try:
                            chunk = json.loads(data)
                            if chunk["choices"][0]["delta"].get("content"):
                                print(chunk["choices"][0]["delta"]["content"], end="", flush=True)
                        except json.JSONDecodeError:
                            continue
                print("\n")
            else:
                print(f"   Error: {await response.aread()}")

async def main():
    """Main test function"""
    print("🚀 Amazon Q Developer Proxy Test Client")
    print("=" * 50)
    
    try:
        # Test direct API
        await test_direct_api()
        
        # Test OpenAI client
        test_openai_client()
        
        # Test streaming
        await test_streaming_api()
        
        print("\n✅ All tests completed!")
        
    except Exception as e:
        print(f"\n❌ Test failed: {e}")

if __name__ == "__main__":
    asyncio.run(main())
