#!/usr/bin/env python3
"""
Example showing how to integrate with existing OpenAI-based applications
"""

import openai
from openai import OpenAI

def example_basic_chat():
    """Basic chat example"""
    print("📝 Basic Chat Example")
    print("-" * 30)
    
    # Configure client to use Amazon Q Developer proxy
    client = OpenAI(
        base_url="http://127.0.0.1:8000/v1",
        api_key="dummy"  # Not used but required
    )
    
    try:
        response = client.chat.completions.create(
            model="amazon-q-developer",
            messages=[
                {"role": "system", "content": "You are a helpful programming assistant."},
                {"role": "user", "content": "How do I create a REST API in Python using FastAPI?"}
            ]
        )
        
        print(f"Response: {response.choices[0].message.content}")
        
    except Exception as e:
        print(f"Error: {e}")

def example_code_generation():
    """Code generation example"""
    print("\n💻 Code Generation Example")
    print("-" * 30)
    
    client = OpenAI(
        base_url="http://127.0.0.1:8000/v1",
        api_key="dummy"
    )
    
    try:
        response = client.chat.completions.create(
            model="amazon-q-developer",
            messages=[
                {"role": "user", "content": """
Write a Python function that:
1. Takes a list of numbers as input
2. Filters out negative numbers
3. Squares each remaining number
4. Returns the sum of all squared numbers

Include proper error handling and docstring.
                """}
            ]
        )
        
        print("Generated code:")
        print(response.choices[0].message.content)
        
    except Exception as e:
        print(f"Error: {e}")

def example_streaming_chat():
    """Streaming chat example"""
    print("\n🌊 Streaming Chat Example")
    print("-" * 30)
    
    client = OpenAI(
        base_url="http://127.0.0.1:8000/v1",
        api_key="dummy"
    )
    
    try:
        stream = client.chat.completions.create(
            model="amazon-q-developer",
            messages=[
                {"role": "user", "content": "Explain the concept of async/await in Python with examples."}
            ],
            stream=True
        )
        
        print("Streaming response:")
        for chunk in stream:
            if chunk.choices[0].delta.content is not None:
                print(chunk.choices[0].delta.content, end="", flush=True)
        print("\n")
        
    except Exception as e:
        print(f"Error: {e}")

def example_conversation():
    """Multi-turn conversation example"""
    print("\n💬 Multi-turn Conversation Example")
    print("-" * 30)
    
    client = OpenAI(
        base_url="http://127.0.0.1:8000/v1",
        api_key="dummy"
    )
    
    # Conversation history
    messages = [
        {"role": "system", "content": "You are a helpful Python tutor."}
    ]
    
    conversation = [
        "What is a Python decorator?",
        "Can you show me a practical example?",
        "How would I create a decorator that measures execution time?"
    ]
    
    try:
        for user_input in conversation:
            print(f"\n👤 User: {user_input}")
            
            # Add user message to conversation
            messages.append({"role": "user", "content": user_input})
            
            # Get response
            response = client.chat.completions.create(
                model="amazon-q-developer",
                messages=messages
            )
            
            assistant_response = response.choices[0].message.content
            print(f"🤖 Assistant: {assistant_response}")
            
            # Add assistant response to conversation
            messages.append({"role": "assistant", "content": assistant_response})
            
    except Exception as e:
        print(f"Error: {e}")

def example_with_langchain():
    """Example using LangChain (if available)"""
    print("\n🦜 LangChain Integration Example")
    print("-" * 30)
    
    try:
        from langchain.llms import OpenAI as LangChainOpenAI
        from langchain.schema import HumanMessage, SystemMessage
        
        # Configure LangChain to use our proxy
        llm = LangChainOpenAI(
            openai_api_base="http://127.0.0.1:8000/v1",
            openai_api_key="dummy",
            model_name="amazon-q-developer"
        )
        
        # Simple query
        response = llm("Write a Python function to reverse a string")
        print(f"LangChain Response: {response}")
        
    except ImportError:
        print("LangChain not installed. Install with: pip install langchain")
    except Exception as e:
        print(f"Error: {e}")

def example_function_calling_simulation():
    """Simulate function calling (tool use)"""
    print("\n🔧 Function Calling Simulation")
    print("-" * 30)
    
    client = OpenAI(
        base_url="http://127.0.0.1:8000/v1",
        api_key="dummy"
    )
    
    try:
        # Simulate a request that might trigger tool use
        response = client.chat.completions.create(
            model="amazon-q-developer",
            messages=[
                {"role": "system", "content": "You are a helpful assistant that can help with file operations and system tasks."},
                {"role": "user", "content": "I need to create a Python script that lists all .py files in the current directory and shows their sizes."}
            ]
        )
        
        print("Response (may include code that could be executed):")
        print(response.choices[0].message.content)
        
    except Exception as e:
        print(f"Error: {e}")

def main():
    """Run all examples"""
    print("🚀 Amazon Q Developer Proxy - OpenAI Integration Examples")
    print("=" * 60)
    
    # Check if server is running
    try:
        client = OpenAI(
            base_url="http://127.0.0.1:8000/v1",
            api_key="dummy"
        )
        
        # Quick health check
        models = client.models.list()
        print(f"✅ Connected to proxy server. Available models: {len(models.data)}")
        
    except Exception as e:
        print(f"❌ Cannot connect to proxy server: {e}")
        print("Make sure the server is running: python cli.py server")
        return
    
    # Run examples
    example_basic_chat()
    example_code_generation()
    example_streaming_chat()
    example_conversation()
    example_with_langchain()
    example_function_calling_simulation()
    
    print("\n✅ All examples completed!")
    print("\n💡 Tips:")
    print("- You can use this proxy with any OpenAI-compatible application")
    print("- Just change the base_url to http://127.0.0.1:8000/v1")
    print("- The API key can be anything (it's not used)")

if __name__ == "__main__":
    main()
