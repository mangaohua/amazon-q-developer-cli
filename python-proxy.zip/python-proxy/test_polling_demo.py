#!/usr/bin/env python3
"""
Demo script showing improved polling behavior
"""

import asyncio
import sys
import os

# Add current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from auth.oauth import DeviceCodeFlow

async def demo_polling():
    """Demo the improved polling behavior"""
    print("🎭 Demo: Improved Login Polling Experience")
    print("=" * 50)
    
    try:
        # Create OAuth flow
        oauth_flow = DeviceCodeFlow("us-east-1")
        
        # Register client
        print("📝 Registering OAuth client...")
        registration_data = await oauth_flow.register_client()
        print(f"   ✅ Registered successfully")
        
        # Start device authorization
        print("\n🚀 Starting device authorization...")
        auth_data = await oauth_flow.start_device_authorization()
        
        print(f"\n🔐 Amazon Q Developer Authentication")
        print("=" * 50)
        print(f"📋 Please visit: {auth_data['verificationUri']}")
        print(f"🔑 Enter code: {auth_data['userCode']}")
        print(f"⏰ Code expires in: {auth_data['expiresIn']} seconds")
        print("=" * 50)
        
        print("\n⏳ Demo: Simulating polling behavior...")
        print("   (In real usage, this would wait for browser authentication)")
        print("   (Press Ctrl+C to stop the demo)")
        
        # Simulate polling for 30 seconds to show the improved UX
        import httpx
        import time
        
        start_time = time.time()
        poll_count = 0
        demo_duration = 30  # Demo for 30 seconds
        
        async with httpx.AsyncClient() as client:
            while time.time() - start_time < demo_duration:
                try:
                    poll_count += 1
                    elapsed = int(time.time() - start_time)
                    print(f"   Polling attempt {poll_count} (elapsed: {elapsed}s)", end="\r", flush=True)
                    
                    response = await client.post(
                        f"{oauth_flow.oidc_url}/token",
                        json={
                            "clientId": oauth_flow.client_id,
                            "clientSecret": oauth_flow.client_secret,
                            "deviceCode": oauth_flow.device_code,
                            "grantType": "urn:ietf:params:oauth:grant-type:device_code"
                        },
                        headers={
                            "Content-Type": "application/x-amz-json-1.1",
                            "X-Amz-Target": "AWSSSOOIDCService.CreateToken"
                        }
                    )
                    
                    if response.status_code == 200:
                        print(f"\n✅ Authentication successful! (This would be real success)")
                        break
                    elif response.status_code == 400:
                        error_data = response.json()
                        error_code = error_data.get("error", "")
                        if error_code == "authorization_pending":
                            # This is expected - continue polling
                            await asyncio.sleep(oauth_flow.interval)
                            continue
                        else:
                            print(f"\n❌ Error: {error_data}")
                            break
                    else:
                        print(f"\n❌ HTTP {response.status_code}")
                        break
                        
                except KeyboardInterrupt:
                    print(f"\n⚠️  Demo cancelled by user")
                    break
                except Exception as e:
                    print(f"\n❌ Error: {e}")
                    break
        
        print(f"\n🎬 Demo completed!")
        print(f"   Total polling attempts: {poll_count}")
        print(f"   Duration: {int(time.time() - start_time)}s")
        print("\n💡 Key improvements:")
        print("   ✅ Clear progress indication")
        print("   ✅ Proper error handling")
        print("   ✅ User-friendly messages")
        print("   ✅ Graceful timeout handling")
        print("   ✅ Keyboard interrupt support")
        
    except KeyboardInterrupt:
        print(f"\n⚠️  Demo cancelled by user")
    except Exception as e:
        print(f"\n❌ Demo failed: {e}")

async def main():
    """Main demo function"""
    await demo_polling()

if __name__ == "__main__":
    asyncio.run(main())
