"""
Amazon Q Developer API client
"""

import sys
import os

# Add parent directory to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import json
import asyncio
from typing import AsyncIterator, Dict, Any, Optional
import httpx
import logging

from .models import ConversationState, ChatResponse, ChatResponseEvent
from auth import BuilderIdAuth

logger = logging.getLogger(__name__)

class QDeveloperClient:
    """Amazon Q Developer API client"""
    
    def __init__(self, region: str = "us-east-1"):
        self.region = region
        self.auth = BuilderIdAuth(region)
        self.base_url = f"https://codewhisperer.{region}.amazonaws.com"
        self.timeout = 300  # 5 minutes
    
    async def _get_headers(self) -> Dict[str, str]:
        """Get request headers with authentication"""
        access_token = await self.auth.get_access_token()
        if not access_token:
            raise Exception("Not authenticated. Please login first.")
        
        return {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/x-amz-json-1.1",
            "X-Amz-Target": "CodeWhispererService.GenerateAssistantResponse",
            "User-Agent": "amazon-q-python-proxy/1.0.0"
        }
    
    async def send_message(self, conversation_state: ConversationState) -> ChatResponse:
        """Send a message and get response"""
        # Check if we're in test mode
        if os.getenv("AMAZON_Q_TEST_MODE") == "true":
            return self._create_mock_response(conversation_state)
        
        headers = await self._get_headers()
        payload = {
            "conversationState": conversation_state.to_codewhisperer_format()
        }
        
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(
                f"{self.base_url}/generateAssistantResponse",
                headers=headers,
                json=payload
            )
            
            if response.status_code == 401:
                raise Exception("Authentication failed. Please login again.")
            elif response.status_code == 429:
                raise Exception("Rate limit exceeded. Please try again later.")
            elif response.status_code != 200:
                raise Exception(f"API request failed: {response.status_code} {response.text}")
            
            # Parse response
            response_data = response.json()
            return self._parse_response(response_data)
    
    async def send_message_stream(self, conversation_state: ConversationState) -> AsyncIterator[ChatResponseEvent]:
        """Send a message and get streaming response"""
        # Check if we're in test mode
        if os.getenv("AMAZON_Q_TEST_MODE") == "true":
            async for event in self._create_mock_stream_response(conversation_state):
                yield event
            return
        
        headers = await self._get_headers()
        payload = {
            "conversationState": conversation_state.to_codewhisperer_format()
        }
        
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            async with client.stream(
                "POST",
                f"{self.base_url}/generateAssistantResponse",
                headers=headers,
                json=payload
            ) as response:
                if response.status_code == 401:
                    raise Exception("Authentication failed. Please login again.")
                elif response.status_code == 429:
                    raise Exception("Rate limit exceeded. Please try again later.")
                elif response.status_code != 200:
                    error_text = await response.aread()
                    raise Exception(f"API request failed: {response.status_code} {error_text.decode()}")
                
                # Parse streaming response
                async for event in self._parse_stream_response(response):
                    yield event
    
    def _create_mock_response(self, conversation_state: ConversationState) -> ChatResponse:
        """Create a mock response for testing"""
        user_content = conversation_state.current_message.content
        
        # Generate a mock response based on the user input
        if "python" in user_content.lower():
            mock_content = """Here's a Python example:

```python
def hello_world():
    print("Hello, World!")
    return "Hello from Amazon Q Developer!"

# Call the function
result = hello_world()
print(result)
```

This is a simple Python function that demonstrates basic syntax and functionality."""
        elif "javascript" in user_content.lower() or "js" in user_content.lower():
            mock_content = """Here's a JavaScript example:

```javascript
function helloWorld() {
    console.log("Hello, World!");
    return "Hello from Amazon Q Developer!";
}

// Call the function
const result = helloWorld();
console.log(result);
```

This is a basic JavaScript function showing modern ES6+ syntax."""
        else:
            mock_content = f"""I understand you're asking about: "{user_content}"

This is a mock response from Amazon Q Developer Python Proxy. In a real implementation, this would be powered by Amazon's AI models.

Here are some key points:
- This is a test response
- The proxy is working correctly
- Authentication is functioning
- API calls are being processed

Feel free to ask more specific questions about programming, AWS services, or development topics!"""
        
        return ChatResponse(
            conversation_id="mock-conv-123",
            message_id="mock-msg-456",
            content=mock_content
        )
    
    async def _create_mock_stream_response(self, conversation_state: ConversationState) -> AsyncIterator[ChatResponseEvent]:
        """Create a mock streaming response for testing"""
        mock_response = self._create_mock_response(conversation_state)
        
        # Split the response into chunks for streaming
        words = mock_response.content.split()
        current_content = ""
        
        for i, word in enumerate(words):
            current_content += word + " "
            
            yield ChatResponseEvent(
                event_type="assistantResponseEvent",
                content=word + " ",
                conversation_id=mock_response.conversation_id,
                message_id=mock_response.message_id
            )
            
            # Add a small delay to simulate streaming
            await asyncio.sleep(0.05)
        
        # Send final event
        yield ChatResponseEvent(
            event_type="conversationComplete",
            content=None,
            conversation_id=mock_response.conversation_id,
            message_id=mock_response.message_id
        )
    
    def _parse_response(self, response_data: Dict[str, Any]) -> ChatResponse:
        """Parse non-streaming response"""
        # This is a simplified parser - actual implementation would depend on 
        # the exact response format from CodeWhisperer API
        conversation_id = response_data.get("conversationId", "")
        message_id = response_data.get("messageId", "")
        content = response_data.get("content", "")
        
        return ChatResponse(
            conversation_id=conversation_id,
            message_id=message_id,
            content=content
        )
    
    async def _parse_stream_response(self, response: httpx.Response) -> AsyncIterator[ChatResponseEvent]:
        """Parse streaming response"""
        buffer = ""
        
        async for chunk in response.aiter_text():
            buffer += chunk
            
            # Process complete events
            while "\n" in buffer:
                line, buffer = buffer.split("\n", 1)
                line = line.strip()
                
                if not line or line.startswith(":"):
                    continue
                
                if line.startswith("data: "):
                    data = line[6:]  # Remove "data: " prefix
                    
                    if data == "[DONE]":
                        return
                    
                    try:
                        event_data = json.loads(data)
                        event = self._parse_event(event_data)
                        if event:
                            yield event
                    except json.JSONDecodeError as e:
                        logger.warning(f"Failed to parse event data: {e}")
                        continue
    
    def _parse_event(self, event_data: Dict[str, Any]) -> Optional[ChatResponseEvent]:
        """Parse individual event from stream"""
        # Determine event type
        event_type = None
        content = None
        conversation_id = None
        message_id = None
        
        # This parsing logic would need to be adapted based on the actual
        # event format from the CodeWhisperer streaming API
        if "assistantResponseEvent" in event_data:
            event_type = "assistantResponseEvent"
            event_content = event_data["assistantResponseEvent"]
            content = event_content.get("content")
            conversation_id = event_content.get("conversationId")
            message_id = event_content.get("messageId")
        elif "conversationTitleEvent" in event_data:
            event_type = "conversationTitleEvent"
            event_content = event_data["conversationTitleEvent"]
            content = event_content.get("title")
            conversation_id = event_content.get("conversationId")
        elif "error" in event_data:
            event_type = "error"
            content = event_data["error"].get("message")
        
        if event_type:
            return ChatResponseEvent(
                event_type=event_type,
                content=content,
                conversation_id=conversation_id,
                message_id=message_id
            )
        
        return None
    
    async def is_authenticated(self) -> bool:
        """Check if client is authenticated"""
        return await self.auth.is_logged_in()
    
    async def login(self):
        """Perform login"""
        return await self.auth.login()
    
    async def logout(self):
        """Perform logout"""
        return await self.auth.logout()
