"""
Data models for API communication
"""

from typing import List, Optional, Dict, Any, Union
from pydantic import BaseModel
from datetime import datetime
from enum import Enum

class ChatTriggerType(str, Enum):
    MANUAL = "Manual"
    AUTO = "Auto"

class MessageType(str, Enum):
    USER_INPUT = "userInputMessage"
    ASSISTANT_RESPONSE = "assistantResponseMessage"

class ChatMessage(BaseModel):
    """Chat message model"""
    content: str
    message_type: MessageType
    created_at: Optional[datetime] = None
    
    def to_codewhisperer_format(self) -> Dict[str, Any]:
        """Convert to CodeWhisperer API format"""
        if self.message_type == MessageType.USER_INPUT:
            return {
                "userInputMessage": {
                    "content": self.content
                }
            }
        else:
            return {
                "assistantResponseMessage": {
                    "content": self.content
                }
            }

class ConversationState(BaseModel):
    """Conversation state model"""
    conversation_id: Optional[str] = None
    current_message: ChatMessage
    history: Optional[List[ChatMessage]] = None
    chat_trigger_type: ChatTriggerType = ChatTriggerType.MANUAL
    
    def to_codewhisperer_format(self) -> Dict[str, Any]:
        """Convert to CodeWhisperer API format"""
        result = {
            "currentMessage": self.current_message.to_codewhisperer_format(),
            "chatTriggerType": self.chat_trigger_type.value
        }
        
        if self.conversation_id:
            result["conversationId"] = self.conversation_id
        
        if self.history:
            result["history"] = [msg.to_codewhisperer_format() for msg in self.history]
        
        return result

class ChatResponseEvent(BaseModel):
    """Individual chat response event"""
    event_type: str
    content: Optional[str] = None
    conversation_id: Optional[str] = None
    message_id: Optional[str] = None

class ChatResponse(BaseModel):
    """Chat response model"""
    conversation_id: str
    message_id: str
    content: str
    events: List[ChatResponseEvent] = []
    
    @classmethod
    def from_stream_events(cls, events: List[Dict[str, Any]]) -> 'ChatResponse':
        """Create response from stream events"""
        conversation_id = ""
        message_id = ""
        content_parts = []
        response_events = []
        
        for event in events:
            event_type = list(event.keys())[0] if event else "unknown"
            event_data = event.get(event_type, {})
            
            response_events.append(ChatResponseEvent(
                event_type=event_type,
                content=event_data.get("content"),
                conversation_id=event_data.get("conversationId"),
                message_id=event_data.get("messageId")
            ))
            
            if event_type == "assistantResponseEvent":
                if "content" in event_data:
                    content_parts.append(event_data["content"])
                if "conversationId" in event_data:
                    conversation_id = event_data["conversationId"]
                if "messageId" in event_data:
                    message_id = event_data["messageId"]
        
        return cls(
            conversation_id=conversation_id,
            message_id=message_id,
            content="".join(content_parts),
            events=response_events
        )

# OpenAI compatible models
class OpenAIMessage(BaseModel):
    """OpenAI compatible message format"""
    role: str  # "user", "assistant", "system"
    content: str

class OpenAIChatRequest(BaseModel):
    """OpenAI compatible chat request"""
    model: str = "amazon-q-developer"
    messages: List[OpenAIMessage]
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    stream: bool = False

class OpenAIChoice(BaseModel):
    """OpenAI compatible choice"""
    index: int
    message: OpenAIMessage
    finish_reason: Optional[str] = "stop"

class OpenAIUsage(BaseModel):
    """OpenAI compatible usage stats"""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0

class OpenAIChatResponse(BaseModel):
    """OpenAI compatible chat response"""
    id: str
    object: str = "chat.completion"
    created: int
    model: str = "amazon-q-developer"
    choices: List[OpenAIChoice]
    usage: OpenAIUsage

class OpenAIStreamChoice(BaseModel):
    """OpenAI compatible streaming choice"""
    index: int
    delta: Dict[str, Any]
    finish_reason: Optional[str] = None

class OpenAIStreamResponse(BaseModel):
    """OpenAI compatible streaming response"""
    id: str
    object: str = "chat.completion.chunk"
    created: int
    model: str = "amazon-q-developer"
    choices: List[OpenAIStreamChoice]
