#!/bin/bash

# Amazon Q Developer Python Proxy Startup Script

set -e

echo "🚀 Amazon Q Developer Python Proxy"
echo "=================================="

# Check if Python is available
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed"
    exit 1
fi

# Check if pip is available
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 is not installed"
    exit 1
fi

# Install dependencies if requirements.txt is newer than last install
if [ ! -f .deps_installed ] || [ requirements.txt -nt .deps_installed ]; then
    echo "📦 Installing dependencies..."
    pip3 install -r requirements.txt
    touch .deps_installed
    echo "✅ Dependencies installed"
fi

# Check authentication status
echo "🔐 Checking authentication status..."
python3 cli.py status

# Ask user what to do
echo ""
echo "What would you like to do?"
echo "1) Start the proxy server"
echo "2) Login to Amazon Q Developer"
echo "3) Check authentication status"
echo "4) Test API connection"
echo "5) Run example client"
echo "6) Exit"

read -p "Enter your choice (1-6): " choice

case $choice in
    1)
        echo "🌐 Starting proxy server..."
        python3 cli.py server
        ;;
    2)
        echo "🔑 Starting login process..."
        python3 cli.py login
        ;;
    3)
        echo "📊 Checking authentication status..."
        python3 cli.py status
        ;;
    4)
        echo "🧪 Testing API connection..."
        python3 cli.py test
        ;;
    5)
        echo "🎯 Running example client..."
        if [ -f examples/test_client.py ]; then
            python3 examples/test_client.py
        else
            echo "❌ Example client not found"
        fi
        ;;
    6)
        echo "👋 Goodbye!"
        exit 0
        ;;
    *)
        echo "❌ Invalid choice"
        exit 1
        ;;
esac
