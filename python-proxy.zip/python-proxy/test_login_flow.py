#!/usr/bin/env python3
"""
Test script for login flow with proper polling
"""

import asyncio
import sys
import os

# Add current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from auth.oauth import DeviceCodeFlow

async def test_oauth_flow():
    """Test OAuth flow with proper error handling"""
    print("🧪 Testing OAuth Device Code Flow")
    print("=" * 40)
    
    try:
        # Create OAuth flow
        oauth_flow = DeviceCodeFlow("us-east-1")
        
        # Register client
        print("1. Registering OAuth client...")
        registration_data = await oauth_flow.register_client()
        print(f"   ✅ Client ID: {registration_data['client_id'][:20]}...")
        
        # Start device authorization
        print("\n2. Starting device authorization...")
        auth_data = await oauth_flow.start_device_authorization()
        
        print(f"   📋 Verification URI: {auth_data['verificationUri']}")
        print(f"   🔑 User Code: {auth_data['userCode']}")
        print(f"   ⏰ Expires in: {auth_data['expiresIn']} seconds")
        print(f"   🔄 Poll interval: {auth_data.get('interval', 5)} seconds")
        
        # Test a few polling attempts (but don't wait for completion)
        print("\n3. Testing polling mechanism...")
        print("   (This will show 'authorization_pending' errors, which is expected)")
        
        import httpx
        import time
        
        async with httpx.AsyncClient() as client:
            for i in range(3):  # Just test 3 attempts
                print(f"   Attempt {i+1}...")
                
                response = await client.post(
                    f"{oauth_flow.oidc_url}/token",
                    json={
                        "clientId": oauth_flow.client_id,
                        "clientSecret": oauth_flow.client_secret,
                        "deviceCode": oauth_flow.device_code,
                        "grantType": "urn:ietf:params:oauth:grant-type:device_code"
                    },
                    headers={
                        "Content-Type": "application/x-amz-json-1.1",
                        "X-Amz-Target": "AWSSSOOIDCService.CreateToken"
                    }
                )
                
                if response.status_code == 200:
                    print("   ✅ Token received (unexpected in test!)")
                    break
                elif response.status_code == 400:
                    error_data = response.json()
                    error_code = error_data.get("error", "")
                    if error_code == "authorization_pending":
                        print(f"   ⏳ Authorization pending (expected)")
                    else:
                        print(f"   ❌ Error: {error_data}")
                else:
                    print(f"   ❌ HTTP {response.status_code}: {response.text}")
                
                if i < 2:  # Don't sleep on last iteration
                    await asyncio.sleep(2)
        
        print("\n✅ OAuth flow test completed successfully!")
        print("   The polling mechanism is working correctly.")
        print("   In real usage, it would continue polling until user completes auth.")
        
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        return False
    
    return True

async def main():
    """Main test function"""
    print("🔧 Testing Login Flow Improvements")
    print("=" * 50)
    
    success = await test_oauth_flow()
    
    if success:
        print("\n🎉 All tests passed!")
        print("\n💡 To test the full login flow:")
        print("   python cli.py logout  # Clear existing auth")
        print("   python cli.py login   # Start new login flow")
        print("   # Complete authentication in browser")
        print("   # The process should now wait properly for you!")
    else:
        print("\n❌ Tests failed!")
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
