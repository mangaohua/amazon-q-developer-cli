# 快速开始指南

## 1. 环境准备

确保你的系统满足以下要求：
- Python 3.8+
- pip
- 网络连接（能访问 AWS 服务）

## 2. 安装依赖

```bash
cd python-proxy
pip install -r requirements.txt
```

## 3. 验证安装

```bash
python check_setup.py
```

这会检查所有必要的组件是否正确安装。

## 4. 认证

首次使用需要登录到 Amazon Q Developer：

```bash
python cli.py login
```

这将：
1. 打开浏览器到 AWS 认证页面
2. 显示一个设备代码
3. 你需要在浏览器中输入这个代码
4. 完成认证后，令牌会安全存储在系统密钥链中

## 5. 启动服务器

```bash
python cli.py server
```

服务器将在 `http://127.0.0.1:8000` 启动。

## 6. 测试 API

### 使用 curl

```bash
curl -X POST http://127.0.0.1:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "amazon-q-developer",
    "messages": [
      {"role": "user", "content": "Hello, world!"}
    ]
  }'
```

### 使用 Python OpenAI 客户端

```python
import openai

client = openai.OpenAI(
    base_url="http://127.0.0.1:8000/v1",
    api_key="dummy"
)

response = client.chat.completions.create(
    model="amazon-q-developer",
    messages=[
        {"role": "user", "content": "Write a Python function to reverse a string"}
    ]
)

print(response.choices[0].message.content)
```

## 7. 常用命令

```bash
# 检查认证状态
python cli.py status

# 测试 API 连接
python cli.py test

# 登出
python cli.py logout

# 启动服务器（自定义端口）
python cli.py server --port 8080

# 查看帮助
python cli.py --help
```

## 8. 故障排除

### 认证问题
```bash
# 重新登录
python cli.py logout
python cli.py login
```

### 网络问题
确保可以访问：
- `https://oidc.us-east-1.amazonaws.com`
- `https://codewhisperer.us-east-1.amazonaws.com`

### 密钥链问题
在 Linux 上安装密钥链服务：
```bash
sudo apt install gnome-keyring
```

## 9. 集成到现有应用

任何支持 OpenAI API 的应用都可以通过修改 base URL 来使用这个代理：

- **Continue.dev**: 设置 API base URL 为 `http://127.0.0.1:8000/v1`
- **Cursor**: 配置自定义 API 端点
- **其他工具**: 类似配置

## 10. 一键启动

使用提供的启动脚本：

```bash
./start.sh
```

这会引导你完成整个设置过程。
