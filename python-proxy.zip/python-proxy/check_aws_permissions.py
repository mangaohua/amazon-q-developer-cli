#!/usr/bin/env python3
"""
检查 AWS 账户的 Amazon Q Developer 权限
"""

import asyncio
import sys
import os
import json

# Add current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import httpx
import boto3
from botocore.exceptions import ClientError, NoCredentialsError

async def check_aws_account_info():
    """检查 AWS 账户基本信息"""
    print("🔍 检查 AWS 账户信息")
    print("=" * 30)
    
    try:
        # 使用 boto3 获取账户信息
        sts_client = boto3.client('sts')
        identity = sts_client.get_caller_identity()
        
        print(f"✅ AWS 账户 ID: {identity.get('Account', 'Unknown')}")
        print(f"✅ 用户 ARN: {identity.get('Arn', 'Unknown')}")
        print(f"✅ 用户 ID: {identity.get('UserId', 'Unknown')}")
        
        return True
        
    except NoCredentialsError:
        print("❌ 未找到 AWS 凭证")
        print("💡 请配置 AWS CLI 或设置环境变量")
        return False
    except ClientError as e:
        print(f"❌ AWS API 错误: {e}")
        return False
    except Exception as e:
        print(f"❌ 未知错误: {e}")
        return False

async def check_codewhisperer_service():
    """检查 CodeWhisperer 服务可用性"""
    print("\n🌐 检查 CodeWhisperer 服务")
    print("=" * 35)
    
    regions_to_check = ['us-east-1', 'us-west-2', 'eu-west-1']
    
    for region in regions_to_check:
        print(f"\n📍 检查地区: {region}")
        
        try:
            # 检查服务端点是否可达
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(
                    f"https://codewhisperer.{region}.amazonaws.com",
                    follow_redirects=True
                )
                
                if response.status_code < 500:
                    print(f"   ✅ 服务端点可达 (状态码: {response.status_code})")
                else:
                    print(f"   ❌ 服务端点错误 (状态码: {response.status_code})")
                    
        except Exception as e:
            print(f"   ❌ 无法连接到服务端点: {e}")

async def check_iam_permissions():
    """检查 IAM 权限"""
    print("\n🔐 检查 IAM 权限")
    print("=" * 20)
    
    try:
        iam_client = boto3.client('iam')
        
        # 获取当前用户信息
        try:
            user_info = iam_client.get_user()
            username = user_info['User']['UserName']
            print(f"✅ 当前 IAM 用户: {username}")
            
            # 检查用户的策略
            try:
                policies = iam_client.list_attached_user_policies(UserName=username)
                print(f"   附加的策略数量: {len(policies['AttachedPolicies'])}")
                
                for policy in policies['AttachedPolicies']:
                    print(f"   - {policy['PolicyName']}")
                    
            except ClientError as e:
                print(f"   ⚠️  无法获取用户策略: {e}")
                
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchEntity':
                print("ℹ️  当前身份不是 IAM 用户（可能是角色或根用户）")
            else:
                print(f"❌ 获取用户信息失败: {e}")
        
        # 尝试模拟 CodeWhisperer 权限检查
        print("\n🧪 模拟权限检查...")
        try:
            # 这里我们不能直接调用 CodeWhisperer API，因为它不是标准的 AWS 服务
            # 但我们可以检查一些相关的权限
            
            # 检查是否有基本的 AWS 权限
            sts_client = boto3.client('sts')
            sts_client.get_caller_identity()
            print("   ✅ 基本 AWS API 访问正常")
            
        except Exception as e:
            print(f"   ❌ 基本 AWS API 访问失败: {e}")
            
    except Exception as e:
        print(f"❌ IAM 检查失败: {e}")

def check_aws_cli_config():
    """检查 AWS CLI 配置"""
    print("\n⚙️  检查 AWS CLI 配置")
    print("=" * 25)
    
    try:
        import subprocess
        
        # 检查 AWS CLI 版本
        result = subprocess.run(['aws', '--version'], capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✅ AWS CLI: {result.stdout.strip()}")
        else:
            print("❌ AWS CLI 未安装")
            return
        
        # 检查配置的地区
        result = subprocess.run(['aws', 'configure', 'get', 'region'], capture_output=True, text=True)
        if result.returncode == 0 and result.stdout.strip():
            region = result.stdout.strip()
            print(f"✅ 配置的地区: {region}")
            
            if region not in ['us-east-1', 'us-west-2', 'eu-west-1']:
                print("   ⚠️  当前地区可能不支持 Amazon Q Developer")
                print("   💡 建议切换到 us-east-1")
        else:
            print("⚠️  未配置默认地区")
        
        # 检查配置的凭证
        result = subprocess.run(['aws', 'sts', 'get-caller-identity'], capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ AWS 凭证配置正确")
        else:
            print("❌ AWS 凭证配置有问题")
            
    except FileNotFoundError:
        print("❌ AWS CLI 未安装")
    except Exception as e:
        print(f"❌ 检查 AWS CLI 配置失败: {e}")

def provide_next_steps():
    """提供下一步建议"""
    print("\n💡 下一步建议")
    print("=" * 15)
    
    print("\n1. 🔐 如果你有 AWS 账户但无法访问 Amazon Q Developer:")
    print("   - 登录 AWS 控制台")
    print("   - 搜索 'Amazon Q' 或 'CodeWhisperer'")
    print("   - 查看服务是否可用并激活")
    
    print("\n2. 🌍 如果服务在你的地区不可用:")
    print("   - 切换到 us-east-1 地区")
    print("   - 重新配置 AWS CLI: aws configure")
    
    print("\n3. 👥 如果是企业账户:")
    print("   - 联系 AWS 管理员")
    print("   - 请求 Amazon Q Developer 访问权限")
    
    print("\n4. 💰 如果需要付费订阅:")
    print("   - 查看 Amazon Q Developer 定价")
    print("   - 考虑升级账户计划")
    
    print("\n5. 🧪 临时解决方案 - 使用测试模式:")
    print("   python cli.py logout")
    print("   AMAZON_Q_TEST_MODE=true python cli.py login")
    print("   python start_server.py")

async def main():
    """主函数"""
    print("🔍 Amazon Q Developer 权限诊断工具")
    print("=" * 50)
    
    # 检查 AWS 账户信息
    account_ok = await check_aws_account_info()
    
    if account_ok:
        # 检查 CodeWhisperer 服务
        await check_codewhisperer_service()
        
        # 检查 IAM 权限
        await check_iam_permissions()
    
    # 检查 AWS CLI 配置
    check_aws_cli_config()
    
    # 提供建议
    provide_next_steps()
    
    print("\n📚 相关文档:")
    print("- Amazon Q Developer: https://docs.aws.amazon.com/amazonq/")
    print("- CodeWhisperer: https://docs.aws.amazon.com/codewhisperer/")
    print("- AWS 支持: https://console.aws.amazon.com/support/")

if __name__ == "__main__":
    asyncio.run(main())
