#!/usr/bin/env python3
"""
Smart server starter that detects authentication mode
"""

import os
import sys
import asyncio
import argparse

# Add current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from auth import BuilderIdAuth

async def check_auth_mode():
    """Check what kind of authentication we have"""
    auth = BuilderIdAuth()
    
    if not await auth.is_logged_in():
        return "none"
    
    token = await auth.get_token()
    if token and "mock_access_token" in token.access_token:
        return "mock"
    else:
        return "real"

def main():
    """Main function"""
    parser = argparse.ArgumentParser(description="Amazon Q Developer Proxy Server")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8000, help="Port to bind to")
    parser.add_argument("--region", default="us-east-1", help="AWS region")
    parser.add_argument("--log-level", default="info", help="Log level")
    parser.add_argument("--force-test-mode", action="store_true", help="Force test mode")
    parser.add_argument("--force-real-mode", action="store_true", help="Force real mode")
    
    args = parser.parse_args()
    
    print("🚀 Amazon Q Developer Proxy Server")
    print("=" * 40)
    
    # Check authentication mode
    if args.force_test_mode:
        auth_mode = "mock"
        print("🧪 Forced test mode")
    elif args.force_real_mode:
        auth_mode = "real"
        print("🔐 Forced real mode")
    else:
        print("🔍 Detecting authentication mode...")
        auth_mode = asyncio.run(check_auth_mode())
    
    # Set environment and provide guidance
    if auth_mode == "none":
        print("❌ No authentication found")
        print("\n💡 Please login first:")
        print("   For real AWS access: python cli.py login")
        print("   For testing: AMAZON_Q_TEST_MODE=true python cli.py login")
        sys.exit(1)
    
    elif auth_mode == "mock":
        print("🧪 Mock authentication detected")
        print("   Using test mode - API calls will return mock responses")
        os.environ["AMAZON_Q_TEST_MODE"] = "true"
        
    elif auth_mode == "real":
        print("✅ Real authentication detected")
        print("   Using real AWS API calls")
        # Ensure test mode is not set
        if "AMAZON_Q_TEST_MODE" in os.environ:
            del os.environ["AMAZON_Q_TEST_MODE"]
    
    print(f"\n🌐 Starting server on {args.host}:{args.port}")
    print("=" * 40)
    
    # Start the server
    import subprocess
    cmd = [
        sys.executable, "server.py",
        "--host", args.host,
        "--port", str(args.port),
        "--region", args.region,
        "--log-level", args.log_level
    ]
    
    try:
        subprocess.run(cmd)
    except KeyboardInterrupt:
        print("\n👋 Server stopped by user")

if __name__ == "__main__":
    main()
