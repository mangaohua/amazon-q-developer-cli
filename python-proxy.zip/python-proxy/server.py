"""
OpenAI-compatible HTTP server for Amazon Q Developer
"""

import sys
import os

# Add current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import asyncio
import json
import time
import uuid
from typing import List, Dict, Any
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import logging

from api.client import QDeveloperClient
from api.models import (
    ConversationState, ChatMessage, MessageType, ChatTriggerType,
    OpenAIChatRequest, OpenAIChatResponse, OpenAIChoice, OpenAIMessage, OpenAIUsage,
    OpenAIStreamResponse, OpenAIStreamChoice
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global client instance
q_client: QDeveloperClient = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    global q_client
    
    # Startup
    logger.info("Starting Amazon Q Developer Proxy Server")
    
    # Check if we're in test mode
    test_mode = os.getenv("AMAZON_Q_TEST_MODE") == "true"
    if test_mode:
        logger.info("🧪 Running in test mode")
        os.environ["AMAZON_Q_TEST_MODE"] = "true"  # Ensure it's set for the client
    
    q_client = QDeveloperClient()
    
    # Check authentication status
    if await q_client.is_authenticated():
        token = await q_client.auth.get_token()
        if token and "mock_access_token" in token.access_token:
            logger.info("🧪 Using mock authentication (test mode)")
        else:
            logger.info("✅ Already authenticated with Amazon Q Developer")
    else:
        logger.warning("⚠️  Not authenticated. Please run the login command first.")
        if not test_mode:
            logger.warning("   Run: python cli.py login")
        else:
            logger.warning("   Run: AMAZON_Q_TEST_MODE=true python cli.py login")
    
    yield
    
    # Shutdown
    logger.info("Shutting down Amazon Q Developer Proxy Server")

# Create FastAPI app
app = FastAPI(
    title="Amazon Q Developer Proxy",
    description="OpenAI-compatible API proxy for Amazon Q Developer",
    version="1.0.0",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Amazon Q Developer Proxy Server",
        "version": "1.0.0",
        "authenticated": await q_client.is_authenticated() if q_client else False
    }

@app.get("/v1/models")
async def list_models():
    """List available models (OpenAI compatible)"""
    return {
        "object": "list",
        "data": [
            {
                "id": "amazon-q-developer",
                "object": "model",
                "created": int(time.time()),
                "owned_by": "amazon",
                "permission": [],
                "root": "amazon-q-developer",
                "parent": None
            }
        ]
    }

@app.post("/v1/chat/completions")
async def chat_completions(request: OpenAIChatRequest):
    """Chat completions endpoint (OpenAI compatible)"""
    global q_client
    
    if not q_client:
        raise HTTPException(status_code=500, detail="Client not initialized")
    
    if not await q_client.is_authenticated():
        raise HTTPException(status_code=401, detail="Not authenticated. Please login first.")
    
    try:
        # Convert OpenAI format to Q Developer format
        conversation_state = await _convert_openai_to_q_format(request)
        
        if request.stream:
            return StreamingResponse(
                _stream_chat_response(conversation_state, request),
                media_type="text/plain"
            )
        else:
            # Non-streaming response
            response = await q_client.send_message(conversation_state)
            return _convert_q_to_openai_format(response, request)
    
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Chat completion error: {error_msg}")
        
        # Handle specific error types
        if "403" in error_msg or "not authorized" in error_msg.lower():
            # Check if we're using a mock token
            token = await q_client.auth.get_token()
            if token and "mock_access_token" in token.access_token:
                raise HTTPException(
                    status_code=403, 
                    detail="Using mock authentication. Please login with real credentials or set AMAZON_Q_TEST_MODE=true"
                )
            else:
                raise HTTPException(
                    status_code=403, 
                    detail="Access denied. Please ensure your AWS account has Amazon Q Developer access."
                )
        elif "401" in error_msg or "authentication" in error_msg.lower():
            raise HTTPException(status_code=401, detail="Authentication failed. Please login again.")
        elif "429" in error_msg or "rate limit" in error_msg.lower():
            raise HTTPException(status_code=429, detail="Rate limit exceeded. Please try again later.")
        else:
            raise HTTPException(status_code=500, detail=f"Internal server error: {error_msg}")

async def _convert_openai_to_q_format(request: OpenAIChatRequest) -> ConversationState:
    """Convert OpenAI request to Q Developer format"""
    if not request.messages:
        raise HTTPException(status_code=400, detail="No messages provided")
    
    # Get the last user message as current message
    user_messages = [msg for msg in request.messages if msg.role == "user"]
    if not user_messages:
        raise HTTPException(status_code=400, detail="No user messages found")
    
    current_message = ChatMessage(
        content=user_messages[-1].content,
        message_type=MessageType.USER_INPUT
    )
    
    # Convert message history (excluding the last user message)
    history = []
    for i, msg in enumerate(request.messages[:-1]):  # Exclude last message
        if msg.role == "user":
            history.append(ChatMessage(
                content=msg.content,
                message_type=MessageType.USER_INPUT
            ))
        elif msg.role == "assistant":
            history.append(ChatMessage(
                content=msg.content,
                message_type=MessageType.ASSISTANT_RESPONSE
            ))
        # Skip system messages for now
    
    return ConversationState(
        current_message=current_message,
        history=history if history else None,
        chat_trigger_type=ChatTriggerType.MANUAL
    )

def _convert_q_to_openai_format(response, request: OpenAIChatRequest) -> OpenAIChatResponse:
    """Convert Q Developer response to OpenAI format"""
    return OpenAIChatResponse(
        id=f"chatcmpl-{uuid.uuid4().hex[:8]}",
        created=int(time.time()),
        model=request.model,
        choices=[
            OpenAIChoice(
                index=0,
                message=OpenAIMessage(
                    role="assistant",
                    content=response.content
                ),
                finish_reason="stop"
            )
        ],
        usage=OpenAIUsage(
            prompt_tokens=len(str(request.messages)),  # Rough estimate
            completion_tokens=len(response.content.split()),  # Rough estimate
            total_tokens=len(str(request.messages)) + len(response.content.split())
        )
    )

async def _stream_chat_response(conversation_state: ConversationState, request: OpenAIChatRequest):
    """Stream chat response in OpenAI format"""
    response_id = f"chatcmpl-{uuid.uuid4().hex[:8]}"
    created = int(time.time())
    
    try:
        async for event in q_client.send_message_stream(conversation_state):
            if event.event_type == "assistantResponseEvent" and event.content:
                # Create streaming response chunk
                chunk = OpenAIStreamResponse(
                    id=response_id,
                    created=created,
                    model=request.model,
                    choices=[
                        OpenAIStreamChoice(
                            index=0,
                            delta={"content": event.content},
                            finish_reason=None
                        )
                    ]
                )
                
                # Format as SSE
                yield f"data: {chunk.model_dump_json()}\n\n"
        
        # Send final chunk
        final_chunk = OpenAIStreamResponse(
            id=response_id,
            created=created,
            model=request.model,
            choices=[
                OpenAIStreamChoice(
                    index=0,
                    delta={},
                    finish_reason="stop"
                )
            ]
        )
        yield f"data: {final_chunk.model_dump_json()}\n\n"
        yield "data: [DONE]\n\n"
        
    except Exception as e:
        logger.error(f"Streaming error: {e}")
        error_chunk = {
            "error": {
                "message": str(e),
                "type": "server_error"
            }
        }
        yield f"data: {json.dumps(error_chunk)}\n\n"

@app.post("/auth/login")
async def login():
    """Login endpoint"""
    global q_client
    
    if not q_client:
        raise HTTPException(status_code=500, detail="Client not initialized")
    
    try:
        await q_client.login()
        return {"message": "Login successful"}
    except Exception as e:
        logger.error(f"Login error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/auth/logout")
async def logout():
    """Logout endpoint"""
    global q_client
    
    if not q_client:
        raise HTTPException(status_code=500, detail="Client not initialized")
    
    try:
        await q_client.logout()
        return {"message": "Logout successful"}
    except Exception as e:
        logger.error(f"Logout error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/auth/status")
async def auth_status():
    """Check authentication status"""
    global q_client
    
    if not q_client:
        return {"authenticated": False, "error": "Client not initialized"}
    
    try:
        authenticated = await q_client.is_authenticated()
        return {"authenticated": authenticated}
    except Exception as e:
        logger.error(f"Auth status error: {e}")
        return {"authenticated": False, "error": str(e)}

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": int(time.time()),
        "authenticated": await q_client.is_authenticated() if q_client else False
    }

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Amazon Q Developer Proxy Server")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8000, help="Port to bind to")
    parser.add_argument("--region", default="us-east-1", help="AWS region")
    parser.add_argument("--log-level", default="info", help="Log level")
    
    args = parser.parse_args()
    
    # Configure logging
    logging.basicConfig(level=getattr(logging, args.log_level.upper()))
    
    print(f"""
🚀 Starting Amazon Q Developer Proxy Server
   Host: {args.host}
   Port: {args.port}
   Region: {args.region}
   
📖 OpenAI Compatible Endpoints:
   • POST /v1/chat/completions
   • GET  /v1/models
   
🔐 Authentication Endpoints:
   • POST /auth/login
   • POST /auth/logout  
   • GET  /auth/status
   
💡 Usage Example:
   curl -X POST http://{args.host}:{args.port}/v1/chat/completions \\
     -H "Content-Type: application/json" \\
     -d '{{"model": "amazon-q-developer", "messages": [{{"role": "user", "content": "Hello!"}}]}}'
""")
    
    uvicorn.run(
        "server:app",
        host=args.host,
        port=args.port,
        log_level=args.log_level,
        reload=False
    )
