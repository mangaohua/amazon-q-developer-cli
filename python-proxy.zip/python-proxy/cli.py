#!/usr/bin/env python3
"""
Command line interface for Amazon Q Developer Proxy
"""

import asyncio
import argparse
import sys
import logging

import sys
import os

# Add current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from auth import BuilderIdAuth
from api import QDeveloperClient

async def login_command(args):
    """Handle login command"""
    auth = BuilderIdAuth(args.region)
    
    try:
        if await auth.is_logged_in():
            print("Already logged in!")
            return
        
        print("Starting login process...")
        await auth.login()
        
    except KeyboardInterrupt:
        print("\nLogin cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"Login failed: {e}")
        sys.exit(1)

async def logout_command(args):
    """Handle logout command"""
    auth = BuilderIdAuth(args.region)
    
    try:
        await auth.logout()
    except Exception as e:
        print(f"Logout failed: {e}")
        sys.exit(1)

async def status_command(args):
    """Handle status command"""
    auth = BuilderIdAuth(args.region)
    
    try:
        is_logged_in = await auth.is_logged_in()
        if is_logged_in:
            token = await auth.get_token()
            print("✅ Authenticated with Amazon Q Developer")
            print(f"   Region: {args.region}")
            if token:
                print(f"   Token expires: {token.expires_at}")
                print(f"   Scopes: {', '.join(token.scopes) if token.scopes else 'None'}")
        else:
            print("❌ Not authenticated")
            print("   Run 'python cli.py login' to authenticate")
    except Exception as e:
        print(f"Status check failed: {e}")
        sys.exit(1)

async def test_command(args):
    """Handle test command"""
    client = QDeveloperClient(args.region)
    
    try:
        if not await client.is_authenticated():
            print("❌ Not authenticated. Please login first.")
            sys.exit(1)
        
        print("🧪 Testing API connection...")
        
        from api.models import ConversationState, ChatMessage, MessageType
        
        # Create test message
        test_message = ChatMessage(
            content="Hello, can you help me with Python?",
            message_type=MessageType.USER_INPUT
        )
        
        conversation = ConversationState(
            current_message=test_message
        )
        
        print("Sending test message...")
        response = await client.send_message(conversation)
        
        print("✅ API test successful!")
        print(f"Response: {response.content[:100]}...")
        
    except Exception as e:
        print(f"❌ API test failed: {e}")
        sys.exit(1)

def start_server_command(args):
    """Handle server start command"""
    import subprocess
    import sys
    
    cmd = [
        sys.executable, "server.py",
        "--host", args.host,
        "--port", str(args.port),
        "--region", args.region,
        "--log-level", args.log_level
    ]
    
    try:
        subprocess.run(cmd)
    except KeyboardInterrupt:
        print("\nServer stopped by user")

def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="Amazon Q Developer Proxy CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python cli.py login                    # Login to Amazon Q Developer
  python cli.py logout                   # Logout
  python cli.py status                   # Check authentication status
  python cli.py test                     # Test API connection
  python cli.py server                   # Start proxy server
  python cli.py server --port 8080      # Start server on port 8080
        """
    )
    
    parser.add_argument(
        "--region", 
        default="us-east-1", 
        help="AWS region (default: us-east-1)"
    )
    
    parser.add_argument(
        "--log-level",
        default="info",
        choices=["debug", "info", "warning", "error"],
        help="Log level (default: info)"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Login command
    login_parser = subparsers.add_parser("login", help="Login to Amazon Q Developer")
    
    # Logout command
    logout_parser = subparsers.add_parser("logout", help="Logout from Amazon Q Developer")
    
    # Status command
    status_parser = subparsers.add_parser("status", help="Check authentication status")
    
    # Test command
    test_parser = subparsers.add_parser("test", help="Test API connection")
    
    # Server command
    server_parser = subparsers.add_parser("server", help="Start proxy server")
    server_parser.add_argument("--host", default="127.0.0.1", help="Host to bind to")
    server_parser.add_argument("--port", type=int, default=8000, help="Port to bind to")
    
    args = parser.parse_args()
    
    # Configure logging
    logging.basicConfig(
        level=getattr(logging, args.log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    if not args.command:
        parser.print_help()
        return
    
    # Handle commands
    if args.command == "login":
        asyncio.run(login_command(args))
    elif args.command == "logout":
        asyncio.run(logout_command(args))
    elif args.command == "status":
        asyncio.run(status_command(args))
    elif args.command == "test":
        asyncio.run(test_command(args))
    elif args.command == "server":
        start_server_command(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
