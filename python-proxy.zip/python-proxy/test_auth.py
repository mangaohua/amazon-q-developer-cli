#!/usr/bin/env python3
"""
Simple test script for authentication system
"""

import asyncio
import sys
from auth import BuilderIdAuth

async def main():
    """Test authentication system"""
    print("🧪 Testing Amazon Q Developer Authentication System")
    print("=" * 50)
    
    # Initialize auth
    auth = BuilderIdAuth()
    
    try:
        # Check current status
        print("1. Checking authentication status...")
        is_logged_in = await auth.is_logged_in()
        print(f"   Currently logged in: {is_logged_in}")
        
        if is_logged_in:
            print("   ✅ Already authenticated!")
            
            # Get token info
            token = await auth.get_token()
            if token:
                print(f"   Token expires at: {token.expires_at}")
                print(f"   Token expired: {token.is_expired()}")
                print(f"   Access token (first 20 chars): {token.access_token[:20]}...")
        else:
            print("   ❌ Not authenticated")
            print("\n2. Starting login process...")
            print("   This will open a browser window for authentication.")
            
            confirm = input("   Continue? (y/N): ")
            if confirm.lower() != 'y':
                print("   Login cancelled.")
                return
            
            # Perform login
            token = await auth.login()
            print(f"   ✅ Login successful!")
            print(f"   Token expires at: {token.expires_at}")
        
        print("\n3. Testing token retrieval...")
        access_token = await auth.get_access_token()
        if access_token:
            print(f"   ✅ Access token retrieved (length: {len(access_token)})")
        else:
            print("   ❌ Failed to retrieve access token")
        
        print("\n✅ Authentication test completed successfully!")
        
    except KeyboardInterrupt:
        print("\n⚠️  Test interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())
