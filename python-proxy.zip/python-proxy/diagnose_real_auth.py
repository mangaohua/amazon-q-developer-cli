#!/usr/bin/env python3
"""
诊断真实 AWS 认证的权限问题
"""

import asyncio
import sys
import os
import json

# Add current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from auth import BuilderIdAuth
import httpx

async def diagnose_real_permissions():
    """诊断真实的 AWS 权限问题"""
    print("🔍 诊断 Amazon Q Developer 权限问题")
    print("=" * 50)
    
    auth = BuilderIdAuth()
    
    # 检查认证状态
    if not await auth.is_logged_in():
        print("❌ 未登录")
        return
    
    token = await auth.get_token()
    if not token:
        print("❌ 无法获取令牌")
        return
    
    # 检查令牌类型
    if "mock_access_token" in token.access_token:
        print("🧪 检测到测试令牌，但你说使用的是真实认证")
        print("💡 请重新登录：")
        print("   python cli.py logout")
        print("   python cli.py login")
        return
    
    print("✅ 使用真实的 AWS 令牌")
    print(f"   令牌长度: {len(token.access_token)} 字符")
    print(f"   过期时间: {token.expires_at}")
    print(f"   权限范围: {', '.join(token.scopes) if token.scopes else '无'}")
    
    # 测试不同的 API 端点
    await test_api_endpoints(token)

async def test_api_endpoints(token):
    """测试不同的 API 端点来诊断权限问题"""
    print("\n🌐 测试 API 端点权限")
    print("=" * 30)
    
    headers = {
        "Authorization": f"Bearer {token.access_token}",
        "Content-Type": "application/x-amz-json-1.1",
        "User-Agent": "amazon-q-python-proxy/1.0.0"
    }
    
    # 测试端点列表
    test_cases = [
        {
            "name": "CodeWhisperer Chat API",
            "url": "https://codewhisperer.us-east-1.amazonaws.com/generateAssistantResponse",
            "target": "CodeWhispererService.GenerateAssistantResponse",
            "payload": {
                "conversationState": {
                    "currentMessage": {
                        "userInputMessage": {
                            "content": "Hello"
                        }
                    },
                    "chatTriggerType": "Manual"
                }
            }
        },
        {
            "name": "CodeWhisperer Completions API", 
            "url": "https://codewhisperer.us-east-1.amazonaws.com/generateCompletions",
            "target": "CodeWhispererService.GenerateCompletions",
            "payload": {
                "fileContext": {
                    "filename": "test.py",
                    "programmingLanguage": {
                        "languageName": "python"
                    },
                    "leftFileContent": "def hello():\n    print("
                }
            }
        }
    ]
    
    async with httpx.AsyncClient(timeout=30.0) as client:
        for test_case in test_cases:
            print(f"\n🧪 测试: {test_case['name']}")
            
            test_headers = headers.copy()
            test_headers["X-Amz-Target"] = test_case["target"]
            
            try:
                response = await client.post(
                    test_case["url"],
                    headers=test_headers,
                    json=test_case["payload"]
                )
                
                print(f"   状态码: {response.status_code}")
                
                if response.status_code == 200:
                    print("   ✅ 成功 - 有权限访问此 API")
                elif response.status_code == 403:
                    error_data = response.json() if response.headers.get('content-type', '').startswith('application/json') else response.text
                    print("   ❌ 403 禁止访问")
                    print(f"   错误详情: {error_data}")
                    
                    # 分析具体的权限问题
                    if isinstance(error_data, dict):
                        message = error_data.get('message', '')
                        if 'not authorized' in message.lower():
                            print("   💡 权限不足 - 账户没有此服务的访问权限")
                        elif 'invalid' in message.lower():
                            print("   💡 令牌无效 - 可能需要重新登录")
                elif response.status_code == 401:
                    print("   ❌ 401 认证失败 - 令牌可能已过期")
                elif response.status_code == 400:
                    print("   ⚠️  400 请求错误 - 但认证可能是有效的")
                    error_data = response.json() if response.headers.get('content-type', '').startswith('application/json') else response.text
                    print(f"   详情: {error_data}")
                else:
                    print(f"   ❓ 未知状态码: {response.status_code}")
                    print(f"   响应: {response.text[:200]}...")
                    
            except Exception as e:
                print(f"   ❌ 请求失败: {e}")

def provide_solutions():
    """提供解决方案"""
    print("\n💡 可能的解决方案")
    print("=" * 20)
    
    print("\n1. 🔐 检查 AWS 账户权限")
    print("   - 登录 AWS 控制台")
    print("   - 搜索 'Amazon Q' 或 'CodeWhisperer'")
    print("   - 确认你的账户有访问权限")
    print("   - 检查是否需要管理员批准")
    
    print("\n2. 📍 检查服务可用性")
    print("   - Amazon Q Developer 可能在某些地区不可用")
    print("   - 确认你的 AWS 账户地区")
    print("   - 尝试切换到 us-east-1 地区")
    
    print("\n3. 👥 企业账户")
    print("   - 如果是企业 AWS 账户，联系管理员")
    print("   - 请求 Amazon Q Developer 访问权限")
    print("   - 确认 IAM 策略包含必要权限")
    
    print("\n4. 🔄 重新认证")
    print("   - 令牌可能有问题，尝试重新登录：")
    print("     python cli.py logout")
    print("     python cli.py login")
    
    print("\n5. 🧪 临时使用测试模式")
    print("   - 如果需要立即测试功能：")
    print("     python cli.py logout")
    print("     AMAZON_Q_TEST_MODE=true python cli.py login")
    print("     python start_server.py")

async def main():
    """主函数"""
    await diagnose_real_permissions()
    provide_solutions()
    
    print("\n🔗 有用的链接")
    print("=" * 15)
    print("- Amazon Q Developer 文档: https://docs.aws.amazon.com/amazonq/")
    print("- AWS 支持中心: https://console.aws.amazon.com/support/")
    print("- CodeWhisperer 权限文档: https://docs.aws.amazon.com/codewhisperer/")

if __name__ == "__main__":
    asyncio.run(main())
