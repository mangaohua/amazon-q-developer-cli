#!/usr/bin/env python3
"""
Complete test suite for Amazon Q Developer Proxy
"""

import asyncio
import json
import time
import subprocess
import sys
import os
import signal
from pathlib import Path

import httpx
import openai

# Set test mode
os.environ["AMAZON_Q_TEST_MODE"] = "true"

class TestRunner:
    def __init__(self):
        self.server_process = None
        self.base_url = "http://127.0.0.1:8000"
        
    async def setup(self):
        """Setup test environment"""
        print("🔧 Setting up test environment...")
        
        # Ensure we're authenticated
        result = subprocess.run([sys.executable, "cli.py", "login"], 
                              capture_output=True, text=True)
        if result.returncode != 0:
            print(f"❌ Login failed: {result.stderr}")
            return False
        
        print("✅ Authentication setup complete")
        return True
    
    def start_server(self):
        """Start the proxy server"""
        print("🚀 Starting proxy server...")
        
        self.server_process = subprocess.Popen([
            sys.executable, "server.py", 
            "--host", "127.0.0.1", 
            "--port", "8000"
        ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        # Wait for server to start
        time.sleep(3)
        
        if self.server_process.poll() is not None:
            stdout, stderr = self.server_process.communicate()
            print(f"❌ Server failed to start: {stderr.decode()}")
            return False
        
        print("✅ Server started successfully")
        return True
    
    def stop_server(self):
        """Stop the proxy server"""
        if self.server_process:
            print("🛑 Stopping proxy server...")
            self.server_process.terminate()
            try:
                self.server_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.server_process.kill()
            print("✅ Server stopped")
    
    async def test_health_endpoint(self):
        """Test health endpoint"""
        print("🏥 Testing health endpoint...")
        
        async with httpx.AsyncClient() as client:
            response = await client.get(f"{self.base_url}/health")
            
            if response.status_code != 200:
                print(f"❌ Health check failed: {response.status_code}")
                return False
            
            data = response.json()
            if data.get("status") != "healthy":
                print(f"❌ Server not healthy: {data}")
                return False
            
            print("✅ Health endpoint working")
            return True
    
    async def test_models_endpoint(self):
        """Test models endpoint"""
        print("📋 Testing models endpoint...")
        
        async with httpx.AsyncClient() as client:
            response = await client.get(f"{self.base_url}/v1/models")
            
            if response.status_code != 200:
                print(f"❌ Models endpoint failed: {response.status_code}")
                return False
            
            data = response.json()
            if not data.get("data") or len(data["data"]) == 0:
                print(f"❌ No models returned: {data}")
                return False
            
            print(f"✅ Models endpoint working ({len(data['data'])} models)")
            return True
    
    async def test_chat_completion(self):
        """Test chat completion endpoint"""
        print("💬 Testing chat completion...")
        
        payload = {
            "model": "amazon-q-developer",
            "messages": [
                {"role": "user", "content": "Write a Python hello world function"}
            ]
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.base_url}/v1/chat/completions",
                json=payload,
                timeout=30.0
            )
            
            if response.status_code != 200:
                print(f"❌ Chat completion failed: {response.status_code} {response.text}")
                return False
            
            data = response.json()
            if not data.get("choices") or len(data["choices"]) == 0:
                print(f"❌ No choices in response: {data}")
                return False
            
            content = data["choices"][0]["message"]["content"]
            if len(content) < 10:
                print(f"❌ Response too short: {content}")
                return False
            
            print(f"✅ Chat completion working (response: {len(content)} chars)")
            return True
    
    async def test_streaming_completion(self):
        """Test streaming chat completion"""
        print("🌊 Testing streaming completion...")
        
        payload = {
            "model": "amazon-q-developer",
            "messages": [
                {"role": "user", "content": "Explain Python variables"}
            ],
            "stream": True
        }
        
        chunks_received = 0
        content_received = ""
        
        async with httpx.AsyncClient() as client:
            async with client.stream(
                "POST",
                f"{self.base_url}/v1/chat/completions",
                json=payload,
                timeout=30.0
            ) as response:
                
                if response.status_code != 200:
                    print(f"❌ Streaming failed: {response.status_code}")
                    return False
                
                async for line in response.aiter_lines():
                    if line.startswith("data: "):
                        data_str = line[6:]
                        if data_str == "[DONE]":
                            break
                        
                        try:
                            chunk_data = json.loads(data_str)
                            if chunk_data.get("choices") and chunk_data["choices"][0].get("delta", {}).get("content"):
                                content_received += chunk_data["choices"][0]["delta"]["content"]
                                chunks_received += 1
                        except json.JSONDecodeError:
                            continue
        
        if chunks_received == 0:
            print("❌ No streaming chunks received")
            return False
        
        if len(content_received) < 10:
            print(f"❌ Streaming content too short: {content_received}")
            return False
        
        print(f"✅ Streaming working ({chunks_received} chunks, {len(content_received)} chars)")
        return True
    
    def test_openai_client(self):
        """Test OpenAI Python client integration"""
        print("🤖 Testing OpenAI client integration...")
        
        try:
            client = openai.OpenAI(
                base_url=f"{self.base_url}/v1",
                api_key="dummy"
            )
            
            response = client.chat.completions.create(
                model="amazon-q-developer",
                messages=[
                    {"role": "user", "content": "What is Python?"}
                ]
            )
            
            if not response.choices or len(response.choices) == 0:
                print("❌ No choices in OpenAI client response")
                return False
            
            content = response.choices[0].message.content
            if len(content) < 10:
                print(f"❌ OpenAI client response too short: {content}")
                return False
            
            print(f"✅ OpenAI client working (response: {len(content)} chars)")
            return True
            
        except Exception as e:
            print(f"❌ OpenAI client test failed: {e}")
            return False
    
    def test_openai_streaming(self):
        """Test OpenAI streaming client"""
        print("🌊 Testing OpenAI streaming client...")
        
        try:
            client = openai.OpenAI(
                base_url=f"{self.base_url}/v1",
                api_key="dummy"
            )
            
            stream = client.chat.completions.create(
                model="amazon-q-developer",
                messages=[
                    {"role": "user", "content": "Explain machine learning"}
                ],
                stream=True
            )
            
            chunks_received = 0
            content_received = ""
            
            for chunk in stream:
                if chunk.choices[0].delta.content is not None:
                    content_received += chunk.choices[0].delta.content
                    chunks_received += 1
            
            if chunks_received == 0:
                print("❌ No streaming chunks from OpenAI client")
                return False
            
            if len(content_received) < 10:
                print(f"❌ OpenAI streaming content too short: {content_received}")
                return False
            
            print(f"✅ OpenAI streaming working ({chunks_received} chunks, {len(content_received)} chars)")
            return True
            
        except Exception as e:
            print(f"❌ OpenAI streaming test failed: {e}")
            return False
    
    async def run_all_tests(self):
        """Run all tests"""
        print("🧪 Amazon Q Developer Proxy - Complete Test Suite")
        print("=" * 60)
        
        # Setup
        if not await self.setup():
            return False
        
        # Start server
        if not self.start_server():
            return False
        
        try:
            # Run tests
            tests = [
                ("Health Endpoint", self.test_health_endpoint()),
                ("Models Endpoint", self.test_models_endpoint()),
                ("Chat Completion", self.test_chat_completion()),
                ("Streaming Completion", self.test_streaming_completion()),
                ("OpenAI Client", self.test_openai_client()),
                ("OpenAI Streaming", self.test_openai_streaming()),
            ]
            
            results = []
            for name, test_coro in tests:
                if asyncio.iscoroutine(test_coro):
                    result = await test_coro
                else:
                    result = test_coro
                results.append((name, result))
            
            # Summary
            print("\n" + "=" * 60)
            print("📊 Test Results Summary")
            print("-" * 30)
            
            passed = 0
            total = len(results)
            
            for name, result in results:
                status = "✅ PASS" if result else "❌ FAIL"
                print(f"   {name}: {status}")
                if result:
                    passed += 1
            
            print(f"\nTotal: {passed}/{total} tests passed")
            
            if passed == total:
                print("🎉 All tests passed! The proxy is working correctly.")
                return True
            else:
                print("⚠️  Some tests failed. Please check the issues above.")
                return False
        
        finally:
            self.stop_server()

async def main():
    """Main test function"""
    runner = TestRunner()
    success = await runner.run_all_tests()
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    asyncio.run(main())
