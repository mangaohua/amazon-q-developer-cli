"""
OAuth 2.0 Device Code Flow implementation for Amazon Q Developer
"""

import asyncio
import json
import time
import webbrowser
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from urllib.parse import urlencode
import httpx
import logging

logger = logging.getLogger(__name__)

class OAuthFlow:
    """Base OAuth flow class"""
    
    def __init__(self, region: str = "us-east-1"):
        self.region = region
        self.oidc_url = f"https://oidc.{region}.amazonaws.com"
        self.start_url = "https://view.awsapps.com/start"
        self.client_name = "Amazon Q for command line"
        self.client_type = "public"
        self.scopes = ["codewhisperer:completions", "codewhisperer:analysis"]

class DeviceCodeFlow(OAuthFlow):
    """OAuth 2.0 Device Code Flow implementation"""
    
    def __init__(self, region: str = "us-east-1"):
        super().__init__(region)
        self.client_id: Optional[str] = None
        self.client_secret: Optional[str] = None
        self.device_code: Optional[str] = None
        self.user_code: Optional[str] = None
        self.verification_uri: Optional[str] = None
        self.verification_uri_complete: Optional[str] = None
        self.expires_in: Optional[int] = None
        self.interval: int = 5
    
    async def register_client(self) -> Dict[str, Any]:
        """Register OAuth client with AWS SSO OIDC"""
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.oidc_url}/client/register",
                json={
                    "clientName": self.client_name,
                    "clientType": self.client_type,
                    "scopes": self.scopes
                },
                headers={
                    "Content-Type": "application/x-amz-json-1.1",
                    "X-Amz-Target": "AWSSSOOIDCService.RegisterClient"
                }
            )
            
            if response.status_code != 200:
                raise Exception(f"Client registration failed: {response.status_code} {response.text}")
            
            data = response.json()
            self.client_id = data["clientId"]
            self.client_secret = data["clientSecret"]
            
            logger.info(f"Client registered successfully: {self.client_id}")
            
            return {
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "client_id_issued_at": data.get("clientIdIssuedAt"),
                "client_secret_expires_at": data.get("clientSecretExpiresAt")
            }
    
    async def start_device_authorization(self) -> Dict[str, Any]:
        """Start device authorization flow"""
        if not self.client_id:
            raise Exception("Client must be registered first")
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.oidc_url}/device_authorization",
                json={
                    "clientId": self.client_id,
                    "clientSecret": self.client_secret,
                    "startUrl": self.start_url
                },
                headers={
                    "Content-Type": "application/x-amz-json-1.1",
                    "X-Amz-Target": "AWSSSOOIDCService.StartDeviceAuthorization"
                }
            )
            
            if response.status_code != 200:
                raise Exception(f"Device authorization failed: {response.status_code} {response.text}")
            
            data = response.json()
            self.device_code = data["deviceCode"]
            self.user_code = data["userCode"]
            self.verification_uri = data["verificationUri"]
            self.verification_uri_complete = data.get("verificationUriComplete")
            self.expires_in = data["expiresIn"]
            self.interval = data.get("interval", 5)
            
            logger.info(f"Device authorization started. User code: {self.user_code}")
            
            return data
    
    def open_browser(self) -> None:
        """Open browser for user authentication"""
        if self.verification_uri_complete:
            webbrowser.open(self.verification_uri_complete)
        else:
            webbrowser.open(self.verification_uri)
    
    async def poll_for_token(self, timeout: int = 300) -> Dict[str, Any]:
        """Poll for access token"""
        if not self.device_code:
            raise Exception("Device authorization must be started first")
        
        start_time = time.time()
        poll_count = 0
        
        print(f"⏳ Waiting for authentication (timeout: {timeout}s)...")
        print("   Please complete the authentication in your browser")
        
        async with httpx.AsyncClient() as client:
            while time.time() - start_time < timeout:
                try:
                    poll_count += 1
                    elapsed = int(time.time() - start_time)
                    print(f"   Polling attempt {poll_count} (elapsed: {elapsed}s)", end="\r", flush=True)
                    
                    response = await client.post(
                        f"{self.oidc_url}/token",
                        json={
                            "clientId": self.client_id,
                            "clientSecret": self.client_secret,
                            "deviceCode": self.device_code,
                            "grantType": "urn:ietf:params:oauth:grant-type:device_code"
                        },
                        headers={
                            "Content-Type": "application/x-amz-json-1.1",
                            "X-Amz-Target": "AWSSSOOIDCService.CreateToken"
                        }
                    )
                    
                    if response.status_code == 200:
                        data = response.json()
                        print(f"\n✅ Authentication successful!")
                        logger.info("Token obtained successfully")
                        return data
                    
                    elif response.status_code == 400:
                        error_data = response.json()
                        error_type = error_data.get("__type", "")
                        error_code = error_data.get("error", "")
                        
                        # Handle different error types
                        if "AuthorizationPendingException" in error_type or error_code == "authorization_pending":
                            # This is expected - user hasn't completed auth yet
                            logger.debug("Authorization pending, continuing to poll...")
                            await asyncio.sleep(self.interval)
                            continue
                        elif "SlowDownException" in error_type or error_code == "slow_down":
                            # Server asking us to slow down
                            logger.debug("Slow down requested, increasing interval")
                            self.interval = min(self.interval + 5, 30)  # Cap at 30 seconds
                            await asyncio.sleep(self.interval)
                            continue
                        elif "ExpiredTokenException" in error_type or error_code == "expired_token":
                            print(f"\n❌ Device code expired. Please try again.")
                            raise Exception("Device code expired")
                        elif "AccessDeniedException" in error_type or error_code == "access_denied":
                            print(f"\n❌ Access denied by user")
                            raise Exception("Access denied by user")
                        else:
                            print(f"\n❌ Authentication error: {error_data}")
                            raise Exception(f"Token request failed: {error_data}")
                    
                    else:
                        print(f"\n❌ HTTP error {response.status_code}: {response.text}")
                        raise Exception(f"Token request failed: {response.status_code} {response.text}")
                
                except httpx.RequestError as e:
                    logger.error(f"Request error during token polling: {e}")
                    print(f"\n⚠️  Network error, retrying in {self.interval}s...")
                    await asyncio.sleep(self.interval)
                    continue
                except Exception as e:
                    # Re-raise non-network exceptions
                    if "Token request failed" in str(e) or "expired" in str(e) or "denied" in str(e):
                        raise
                    logger.error(f"Unexpected error during token polling: {e}")
                    await asyncio.sleep(self.interval)
                    continue
        
        print(f"\n⏰ Authentication timeout after {timeout}s")
        raise Exception("Authentication timeout - please try again")
    
    async def refresh_token(self, refresh_token: str) -> Dict[str, Any]:
        """Refresh access token using refresh token"""
        if not self.client_id:
            raise Exception("Client must be registered first")
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.oidc_url}/token",
                json={
                    "clientId": self.client_id,
                    "clientSecret": self.client_secret,
                    "refreshToken": refresh_token,
                    "grantType": "refresh_token"
                },
                headers={
                    "Content-Type": "application/x-amz-json-1.1",
                    "X-Amz-Target": "AWSSSOOIDCService.CreateToken"
                }
            )
            
            if response.status_code != 200:
                raise Exception(f"Token refresh failed: {response.status_code} {response.text}")
            
            data = response.json()
            logger.info("Token refreshed successfully")
            return data
