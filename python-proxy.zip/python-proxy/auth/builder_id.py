"""
Builder ID authentication implementation
"""

import json
import asyncio
import os
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
import logging

from .database import AuthDatabase
from .oauth import DeviceCodeFlow

logger = logging.getLogger(__name__)

class BuilderIdToken:
    """Builder ID token management"""
    
    SECRET_KEY = "codewhisperer:oidc:token"
    
    def __init__(self, access_token: str, expires_at: datetime, 
                 refresh_token: Optional[str] = None, region: str = "us-east-1",
                 start_url: Optional[str] = None, scopes: Optional[list] = None):
        self.access_token = access_token
        self.expires_at = expires_at
        self.refresh_token = refresh_token
        self.region = region
        self.start_url = start_url
        self.scopes = scopes or []
    
    def is_expired(self, buffer_minutes: int = 1) -> bool:
        """Check if token is expired (with buffer)"""
        now = datetime.utcnow()
        return (now + timedelta(minutes=buffer_minutes)) >= self.expires_at
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert token to dictionary for storage"""
        return {
            "access_token": self.access_token,
            "expires_at": self.expires_at.isoformat(),
            "refresh_token": self.refresh_token,
            "region": self.region,
            "start_url": self.start_url,
            "scopes": self.scopes
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BuilderIdToken':
        """Create token from dictionary"""
        return cls(
            access_token=data["access_token"],
            expires_at=datetime.fromisoformat(data["expires_at"]),
            refresh_token=data.get("refresh_token"),
            region=data.get("region", "us-east-1"),
            start_url=data.get("start_url"),
            scopes=data.get("scopes", [])
        )
    
    @classmethod
    def from_oauth_response(cls, oauth_data: Dict[str, Any], region: str = "us-east-1",
                           start_url: Optional[str] = None, scopes: Optional[list] = None) -> 'BuilderIdToken':
        """Create token from OAuth response"""
        expires_in = oauth_data.get("expiresIn", 3600)
        expires_at = datetime.utcnow() + timedelta(seconds=expires_in)
        
        return cls(
            access_token=oauth_data["accessToken"],
            expires_at=expires_at,
            refresh_token=oauth_data.get("refreshToken"),
            region=region,
            start_url=start_url,
            scopes=scopes
        )
    
    @classmethod
    def create_mock_token(cls, region: str = "us-east-1") -> 'BuilderIdToken':
        """Create a mock token for testing"""
        return cls(
            access_token="mock_access_token_" + "x" * 100,
            expires_at=datetime.utcnow() + timedelta(hours=1),
            refresh_token="mock_refresh_token_" + "y" * 50,
            region=region,
            start_url="https://view.awsapps.com/start",
            scopes=["codewhisperer:completions", "codewhisperer:analysis"]
        )
    
    async def save(self, database: AuthDatabase) -> None:
        """Save token to secure storage"""
        token_json = json.dumps(self.to_dict())
        database.store_secret(self.SECRET_KEY, token_json)
        logger.info("Token saved successfully")
    
    @classmethod
    async def load(cls, database: AuthDatabase) -> Optional['BuilderIdToken']:
        """Load token from secure storage"""
        token_json = database.get_secret(cls.SECRET_KEY)
        if not token_json:
            return None
        
        try:
            token_data = json.loads(token_json)
            token = cls.from_dict(token_data)
            
            # Check if token needs refresh
            if token.is_expired():
                logger.info("Token is expired, attempting refresh")
                refreshed_token = await token.refresh(database)
                return refreshed_token
            
            return token
        except (json.JSONDecodeError, KeyError) as e:
            logger.error(f"Failed to load token: {e}")
            return None
    
    async def refresh(self, database: AuthDatabase) -> Optional['BuilderIdToken']:
        """Refresh the access token"""
        if not self.refresh_token:
            logger.warning("No refresh token available, token cannot be refreshed")
            await self.delete(database)
            return None
        
        try:
            # Load device registration
            device_registration = await DeviceRegistration.load(database, self.region)
            if not device_registration:
                logger.warning("No device registration found, cannot refresh token")
                return None
            
            # Create OAuth flow and refresh token
            oauth_flow = DeviceCodeFlow(self.region)
            oauth_flow.client_id = device_registration.client_id
            oauth_flow.client_secret = device_registration.client_secret
            
            oauth_data = await oauth_flow.refresh_token(self.refresh_token)
            
            # Create new token
            new_token = self.from_oauth_response(
                oauth_data, self.region, self.start_url, self.scopes
            )
            
            # Save new token
            await new_token.save(database)
            logger.info("Token refreshed successfully")
            return new_token
            
        except Exception as e:
            logger.error(f"Failed to refresh token: {e}")
            await self.delete(database)
            return None
    
    async def delete(self, database: AuthDatabase) -> None:
        """Delete token from secure storage"""
        try:
            database.delete_secret(self.SECRET_KEY)
            logger.info("Token deleted successfully")
        except Exception as e:
            logger.error(f"Failed to delete token: {e}")

class DeviceRegistration:
    """Device registration management"""
    
    SECRET_KEY = "codewhisperer:oidc:device_registration"
    
    def __init__(self, client_id: str, client_secret: str, region: str = "us-east-1"):
        self.client_id = client_id
        self.client_secret = client_secret
        self.region = region
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert registration to dictionary for storage"""
        return {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "region": self.region
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DeviceRegistration':
        """Create registration from dictionary"""
        return cls(
            client_id=data["client_id"],
            client_secret=data["client_secret"],
            region=data.get("region", "us-east-1")
        )
    
    async def save(self, database: AuthDatabase) -> None:
        """Save registration to secure storage"""
        registration_json = json.dumps(self.to_dict())
        database.store_secret(self.SECRET_KEY, registration_json)
        logger.info("Device registration saved successfully")
    
    @classmethod
    async def load(cls, database: AuthDatabase, region: str = "us-east-1") -> Optional['DeviceRegistration']:
        """Load registration from secure storage"""
        registration_json = database.get_secret(cls.SECRET_KEY)
        if not registration_json:
            return None
        
        try:
            registration_data = json.loads(registration_json)
            registration = cls.from_dict(registration_data)
            
            # Check if region matches
            if registration.region != region:
                logger.warning(f"Region mismatch: stored={registration.region}, requested={region}")
                return None
            
            return registration
        except (json.JSONDecodeError, KeyError) as e:
            logger.error(f"Failed to load device registration: {e}")
            return None

class BuilderIdAuth:
    """Main authentication class for Builder ID"""
    
    def __init__(self, region: str = "us-east-1"):
        self.region = region
        self.database = AuthDatabase()
    
    async def is_logged_in(self) -> bool:
        """Check if user is logged in"""
        token = await BuilderIdToken.load(self.database)
        return token is not None
    
    async def login(self) -> BuilderIdToken:
        """Perform login flow"""
        if await self.is_logged_in():
            raise Exception("Already logged in. Please logout first.")
        
        # Check if we're in test mode
        if os.getenv("AMAZON_Q_TEST_MODE") == "true":
            print("🧪 Test mode enabled - creating mock token")
            token = BuilderIdToken.create_mock_token(self.region)
            await token.save(self.database)
            print("✅ Mock login successful!")
            return token
        
        # Create OAuth flow
        oauth_flow = DeviceCodeFlow(self.region)
        
        # Check for existing device registration
        device_registration = await DeviceRegistration.load(self.database, self.region)
        
        if device_registration:
            logger.info("Using existing device registration")
            oauth_flow.client_id = device_registration.client_id
            oauth_flow.client_secret = device_registration.client_secret
        else:
            logger.info("Registering new OAuth client")
            registration_data = await oauth_flow.register_client()
            device_registration = DeviceRegistration(
                client_id=registration_data["client_id"],
                client_secret=registration_data["client_secret"],
                region=self.region
            )
            await device_registration.save(self.database)
        
        # Start device authorization
        auth_data = await oauth_flow.start_device_authorization()
        
        print(f"\n🔐 Amazon Q Developer Authentication")
        print("=" * 50)
        print(f"📋 Please visit: {auth_data['verificationUri']}")
        print(f"🔑 Enter code: {auth_data['userCode']}")
        print(f"⏰ Code expires in: {auth_data['expiresIn']} seconds")
        print("=" * 50)
        
        # Open browser
        try:
            oauth_flow.open_browser()
            print("🌐 Browser opened automatically")
        except Exception as e:
            print(f"⚠️  Could not open browser automatically: {e}")
            print("   Please open the URL manually in your browser")
        
        print("\n⏳ Waiting for you to complete authentication in the browser...")
        print("   (You can press Ctrl+C to cancel)")
        
        # Poll for token with better timeout
        try:
            token_data = await oauth_flow.poll_for_token(timeout=auth_data['expiresIn'])
        except KeyboardInterrupt:
            print("\n❌ Authentication cancelled by user")
            raise Exception("Authentication cancelled")
        
        # Create and save token
        token = BuilderIdToken.from_oauth_response(
            token_data, self.region, oauth_flow.start_url, oauth_flow.scopes
        )
        await token.save(self.database)
        
        print("\n🎉 Login successful!")
        print(f"   Token expires: {token.expires_at}")
        print(f"   Scopes: {', '.join(token.scopes) if token.scopes else 'None'}")
        return token
    
    async def logout(self) -> None:
        """Perform logout"""
        # Clear all authentication data
        self.database.clear_all_auth_data()
        print("Logout successful!")
    
    async def get_access_token(self) -> Optional[str]:
        """Get current access token"""
        token = await BuilderIdToken.load(self.database)
        return token.access_token if token else None
    
    async def get_token(self) -> Optional[BuilderIdToken]:
        """Get current token object"""
        return await BuilderIdToken.load(self.database)
