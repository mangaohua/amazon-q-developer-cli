"""
Database module for storing authentication tokens securely
"""

import sqlite3
import json
import os
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime
import logging

from .simple_storage import SimpleSecureStorage

logger = logging.getLogger(__name__)

class AuthDatabase:
    """Secure storage for authentication tokens using encrypted files"""
    
    def __init__(self, db_path: Optional[str] = None):
        if db_path is None:
            # Use user's home directory for database
            home_dir = Path.home()
            self.db_path = home_dir / ".amazon-q" / "auth.db"
        else:
            self.db_path = Path(db_path)
        
        # Ensure directory exists
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Initialize secure storage
        self.secure_storage = SimpleSecureStorage(self.db_path.parent / "secure_storage")
        
        # Initialize database
        self._init_db()
    
    def _init_db(self):
        """Initialize the SQLite database"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS auth_profiles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    profile_name TEXT UNIQUE NOT NULL,
                    arn TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            conn.commit()
    
    def store_secret(self, key: str, value: str) -> None:
        """Store a secret using secure file storage"""
        self.secure_storage.store_secret(key, value)
    
    def get_secret(self, key: str) -> Optional[str]:
        """Retrieve a secret from secure file storage"""
        return self.secure_storage.get_secret(key)
    
    def delete_secret(self, key: str) -> None:
        """Delete a secret from secure file storage"""
        self.secure_storage.delete_secret(key)
    
    def set_auth_profile(self, profile_name: str, arn: Optional[str] = None) -> None:
        """Set the current authentication profile"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO auth_profiles (profile_name, arn, updated_at)
                VALUES (?, ?, CURRENT_TIMESTAMP)
            """, (profile_name, arn))
            conn.commit()
    
    def get_auth_profile(self) -> Optional[Dict[str, Any]]:
        """Get the current authentication profile"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("""
                SELECT profile_name, arn, created_at, updated_at
                FROM auth_profiles
                ORDER BY updated_at DESC
                LIMIT 1
            """)
            row = cursor.fetchone()
            if row:
                return {
                    'profile_name': row[0],
                    'arn': row[1],
                    'created_at': row[2],
                    'updated_at': row[3]
                }
        return None
    
    def unset_auth_profile(self) -> None:
        """Remove all authentication profiles"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("DELETE FROM auth_profiles")
            conn.commit()
    
    def set_setting(self, key: str, value: Any) -> None:
        """Store a setting"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO settings (key, value, updated_at)
                VALUES (?, ?, CURRENT_TIMESTAMP)
            """, (key, json.dumps(value)))
            conn.commit()
    
    def get_setting(self, key: str, default: Any = None) -> Any:
        """Retrieve a setting"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("SELECT value FROM settings WHERE key = ?", (key,))
            row = cursor.fetchone()
            if row:
                try:
                    return json.loads(row[0])
                except json.JSONDecodeError:
                    return row[0]
        return default
    
    def clear_all_auth_data(self) -> None:
        """Clear all authentication data"""
        # Clear secrets
        self.secure_storage.clear_all_secrets()
        
        # Clear database
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("DELETE FROM auth_profiles")
            conn.commit()
