"""
Simple secure storage implementation as fallback for keyring issues
"""

import json
import os
import base64
from pathlib import Path
from typing import Optional, Dict, Any
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import logging

logger = logging.getLogger(__name__)

class SimpleSecureStorage:
    """Simple secure storage using encrypted files"""
    
    def __init__(self, storage_dir: Optional[str] = None):
        if storage_dir is None:
            # Use user's home directory for storage
            home_dir = Path.home()
            self.storage_dir = home_dir / ".amazon-q" / "secure_storage"
        else:
            self.storage_dir = Path(storage_dir)
        
        # Ensure directory exists
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize encryption
        self._encryption_key = self._get_or_create_key()
    
    def _get_or_create_key(self) -> bytes:
        """Get or create encryption key"""
        key_file = self.storage_dir / ".key"
        
        if key_file.exists():
            try:
                with open(key_file, 'rb') as f:
                    key_data = f.read()
                    if len(key_data) >= 48:  # 16 bytes salt + 32 bytes key
                        return key_data[16:]  # Return just the key part
            except Exception as e:
                logger.warning(f"Failed to read existing key: {e}")
        
        # Generate new key
        password = b"amazon-q-developer-proxy-v1"
        salt = os.urandom(16)
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(password))
        
        # Store salt + key
        try:
            with open(key_file, 'wb') as f:
                f.write(salt + key)
            
            # Set restrictive permissions on Unix-like systems
            if hasattr(os, 'chmod'):
                os.chmod(key_file, 0o600)
        except Exception as e:
            logger.error(f"Failed to store encryption key: {e}")
            raise
        
        return key
    
    def store_secret(self, key: str, value: str) -> None:
        """Store a secret"""
        try:
            fernet = Fernet(self._encryption_key)
            encrypted_value = fernet.encrypt(value.encode('utf-8'))
            
            # Use safe filename
            safe_key = key.replace(':', '_').replace('/', '_').replace('\\', '_')
            secret_file = self.storage_dir / f"{safe_key}.enc"
            
            with open(secret_file, 'wb') as f:
                f.write(encrypted_value)
            
            # Set restrictive permissions on Unix-like systems
            if hasattr(os, 'chmod'):
                os.chmod(secret_file, 0o600)
            
            logger.debug(f"Stored secret for key: {key}")
        except Exception as e:
            logger.error(f"Failed to store secret for key {key}: {e}")
            raise
    
    def get_secret(self, key: str) -> Optional[str]:
        """Retrieve a secret"""
        try:
            safe_key = key.replace(':', '_').replace('/', '_').replace('\\', '_')
            secret_file = self.storage_dir / f"{safe_key}.enc"
            
            if not secret_file.exists():
                return None
            
            fernet = Fernet(self._encryption_key)
            
            with open(secret_file, 'rb') as f:
                encrypted_value = f.read()
            
            decrypted_value = fernet.decrypt(encrypted_value)
            logger.debug(f"Retrieved secret for key: {key}")
            return decrypted_value.decode('utf-8')
        
        except Exception as e:
            logger.error(f"Failed to retrieve secret for key {key}: {e}")
            return None
    
    def delete_secret(self, key: str) -> None:
        """Delete a secret"""
        try:
            safe_key = key.replace(':', '_').replace('/', '_').replace('\\', '_')
            secret_file = self.storage_dir / f"{safe_key}.enc"
            
            if secret_file.exists():
                secret_file.unlink()
                logger.debug(f"Deleted secret for key: {key}")
        except Exception as e:
            logger.error(f"Failed to delete secret for key {key}: {e}")
    
    def clear_all_secrets(self) -> None:
        """Clear all stored secrets"""
        try:
            for secret_file in self.storage_dir.glob("*.enc"):
                secret_file.unlink()
            logger.info("Cleared all secrets")
        except Exception as e:
            logger.error(f"Failed to clear secrets: {e}")
