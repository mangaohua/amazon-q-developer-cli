#!/usr/bin/env python3
"""
Demo script showing Amazon Q Developer Proxy usage
"""

import asyncio
import os
import sys
import time
import subprocess
import signal

# Set test mode for demo
os.environ["AMAZON_Q_TEST_MODE"] = "true"

import openai

def start_server():
    """Start the proxy server in background"""
    print("🚀 Starting Amazon Q Developer Proxy Server...")
    
    process = subprocess.Popen([
        sys.executable, "server.py",
        "--host", "127.0.0.1",
        "--port", "8000"
    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # Wait for server to start
    time.sleep(3)
    
    if process.poll() is not None:
        stdout, stderr = process.communicate()
        print(f"❌ Server failed to start: {stderr.decode()}")
        return None
    
    print("✅ Server started at http://127.0.0.1:8000")
    return process

def demo_basic_usage():
    """Demo basic OpenAI client usage"""
    print("\n" + "="*50)
    print("📝 Demo: Basic Chat Completion")
    print("="*50)
    
    client = openai.OpenAI(
        base_url="http://127.0.0.1:8000/v1",
        api_key="dummy"  # Not used but required
    )
    
    print("🤖 Asking: 'Write a Python function to calculate factorial'")
    
    response = client.chat.completions.create(
        model="amazon-q-developer",
        messages=[
            {"role": "system", "content": "You are a helpful programming assistant."},
            {"role": "user", "content": "Write a Python function to calculate factorial"}
        ]
    )
    
    print("\n📤 Response:")
    print(response.choices[0].message.content)

def demo_streaming():
    """Demo streaming response"""
    print("\n" + "="*50)
    print("🌊 Demo: Streaming Response")
    print("="*50)
    
    client = openai.OpenAI(
        base_url="http://127.0.0.1:8000/v1",
        api_key="dummy"
    )
    
    print("🤖 Asking: 'Explain async/await in Python'")
    print("\n📤 Streaming Response:")
    
    stream = client.chat.completions.create(
        model="amazon-q-developer",
        messages=[
            {"role": "user", "content": "Explain async/await in Python with a simple example"}
        ],
        stream=True
    )
    
    for chunk in stream:
        if chunk.choices[0].delta.content is not None:
            print(chunk.choices[0].delta.content, end="", flush=True)
    
    print("\n")

def demo_conversation():
    """Demo multi-turn conversation"""
    print("\n" + "="*50)
    print("💬 Demo: Multi-turn Conversation")
    print("="*50)
    
    client = openai.OpenAI(
        base_url="http://127.0.0.1:8000/v1",
        api_key="dummy"
    )
    
    # Conversation history
    messages = [
        {"role": "system", "content": "You are a helpful Python tutor."}
    ]
    
    questions = [
        "What is a Python list?",
        "How do I add items to a list?",
        "Can you show me an example?"
    ]
    
    for question in questions:
        print(f"\n👤 User: {question}")
        
        # Add user message
        messages.append({"role": "user", "content": question})
        
        # Get response
        response = client.chat.completions.create(
            model="amazon-q-developer",
            messages=messages
        )
        
        assistant_response = response.choices[0].message.content
        print(f"🤖 Assistant: {assistant_response[:200]}...")
        
        # Add assistant response to conversation
        messages.append({"role": "assistant", "content": assistant_response})

def demo_curl_examples():
    """Show curl examples"""
    print("\n" + "="*50)
    print("🌐 Demo: cURL Examples")
    print("="*50)
    
    examples = [
        {
            "name": "Health Check",
            "command": "curl -s http://127.0.0.1:8000/health"
        },
        {
            "name": "List Models",
            "command": "curl -s http://127.0.0.1:8000/v1/models"
        },
        {
            "name": "Chat Completion",
            "command": '''curl -s -X POST http://127.0.0.1:8000/v1/chat/completions \\
  -H "Content-Type: application/json" \\
  -d '{"model": "amazon-q-developer", "messages": [{"role": "user", "content": "Hello!"}]}'
'''
        }
    ]
    
    for example in examples:
        print(f"\n📋 {example['name']}:")
        print(f"   {example['command']}")

def main():
    """Main demo function"""
    print("🎯 Amazon Q Developer Proxy - Interactive Demo")
    print("=" * 60)
    
    # Ensure authentication
    print("🔐 Setting up authentication...")
    result = subprocess.run([sys.executable, "cli.py", "login"], 
                          capture_output=True, text=True)
    if result.returncode != 0:
        print(f"❌ Authentication failed: {result.stderr}")
        return
    
    print("✅ Authentication successful")
    
    # Start server
    server_process = start_server()
    if not server_process:
        return
    
    try:
        # Run demos
        demo_basic_usage()
        demo_streaming()
        demo_conversation()
        demo_curl_examples()
        
        print("\n" + "="*60)
        print("🎉 Demo completed successfully!")
        print("\n💡 Integration Tips:")
        print("   • Use base_url='http://127.0.0.1:8000/v1' in OpenAI clients")
        print("   • API key can be anything (not used)")
        print("   • Supports both streaming and non-streaming")
        print("   • Compatible with any OpenAI-compatible tool")
        
        print("\n🔗 Try these integrations:")
        print("   • Continue.dev: Set API base URL to http://127.0.0.1:8000/v1")
        print("   • Cursor: Configure custom API endpoint")
        print("   • LangChain: Use OpenAI wrapper with custom base_url")
        
    except KeyboardInterrupt:
        print("\n⚠️  Demo interrupted by user")
    except Exception as e:
        print(f"\n❌ Demo failed: {e}")
    finally:
        # Stop server
        if server_process:
            print("\n🛑 Stopping server...")
            server_process.terminate()
            try:
                server_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                server_process.kill()
            print("✅ Server stopped")

if __name__ == "__main__":
    main()
